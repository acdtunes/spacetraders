import { useEffect, useRef, useState } from 'react';
import * as PIXI from 'pixi.js';
import { useStore } from '../store/useStore';
import { getAllSystems } from '../services/api';
import { usePixiCanvas } from '../hooks/usePixiCanvas';
import { PIXI_CONSTANTS } from '../constants/pixi';

const GalaxyView = () => {
  const canvasRef = useRef<HTMLDivElement>(null);
  const { systems, setSystems, ships, currentSystem, setCurrentSystem, setViewMode } = useStore();
  const [isLoading, setIsLoading] = useState(false);

  // Initialize PixiJS canvas with pan and zoom
  const { app, container } = usePixiCanvas(canvasRef, {
    width: window.innerWidth - 256, // Subtract sidebar width
    height: window.innerHeight - 64, // Subtract header height
    minScale: PIXI_CONSTANTS.MIN_ZOOM_GALAXY,
    maxScale: PIXI_CONSTANTS.MAX_ZOOM_GALAXY,
  });

  // Fetch all systems if not already loaded
  useEffect(() => {
    if (systems.length === 0 && !isLoading) {
      setIsLoading(true);
      getAllSystems()
        .then((data) => {
          setSystems(data);
          setIsLoading(false);
        })
        .catch((error) => {
          console.error('Failed to load systems:', error);
          setIsLoading(false);
        });
    }
  }, [systems.length, setSystems, isLoading]);

  // Render systems
  useEffect(() => {
    if (!container || systems.length === 0) return;

    container.removeChildren();

    const graphics = new PIXI.Graphics();

    // Count ships per system
    const shipCounts = new Map<string, number>();
    ships.forEach((ship: any) => {
      const count = shipCounts.get(ship.nav.systemSymbol) || 0;
      shipCounts.set(ship.nav.systemSymbol, count + 1);
    });

    // Draw systems
    systems.forEach((system) => {
      const shipCount = shipCounts.get(system.symbol) || 0;
      const hasShips = shipCount > 0;

      // Calculate radius based on waypoint count
      const baseRadius = 2;
      const radius = baseRadius + Math.min(system.waypoints.length / 20, 5);

      // Color based on whether it has ships
      const color = hasShips ? 0x4ECDC4 : 0x666666;

      // Highlight current system
      if (system.symbol === currentSystem) {
        graphics.circle(system.x, system.y, radius + 4);
        graphics.stroke({ color: 0xFFE66D, width: 2, alpha: 0.8 });
      }

      graphics.circle(system.x, system.y, radius);
      graphics.fill({ color, alpha: hasShips ? 0.9 : 0.5 });

      // Make system interactive
      const interactiveCircle = new PIXI.Graphics();
      interactiveCircle.circle(system.x, system.y, radius + 3);
      interactiveCircle.fill({ color: 0x000000, alpha: 0.001 }); // Invisible but interactive
      interactiveCircle.eventMode = 'static';
      interactiveCircle.cursor = 'pointer';

      // Add hover effect and click handler
      interactiveCircle.on('pointerover', () => {
        // Show system name on hover
        const hoverGraphics = new PIXI.Graphics();
        hoverGraphics.circle(system.x, system.y, radius + 2);
        hoverGraphics.stroke({ color: 0xffffff, width: 1, alpha: 0.8 });
        hoverGraphics.label = 'hover';
        container.addChild(hoverGraphics);
      });

      interactiveCircle.on('pointerout', () => {
        // Remove hover effects
        const toRemove = container.children.filter((child) => child.label === 'hover');
        toRemove.forEach((child) => container.removeChild(child));
      });

      interactiveCircle.on('click', () => {
        // Navigate to system
        setCurrentSystem(system.symbol);
        setViewMode('system');
      });

      container.addChild(interactiveCircle);

      // Add ship count label if there are ships
      if (hasShips) {
        const label = new PIXI.Text(shipCount.toString(), {
          fontSize: 12,
          fill: 0xffffff,
          fontWeight: 'bold',
        });
        label.anchor.set(0.5);
        label.x = system.x;
        label.y = system.y;
        container.addChild(label);
      }

      // Add system symbol label (small, faded)
      const symbolLabel = new PIXI.Text(system.symbol, {
        fontSize: 8,
        fill: 0xffffff,
      });
      symbolLabel.alpha = 0.3;
      symbolLabel.x = system.x + radius + 2;
      symbolLabel.y = system.y - 4;
      container.addChild(symbolLabel);
    });

    container.addChild(graphics);

    // Center view on systems with ships, or all systems if none
    if (systems.length > 0 && app) {
      const systemsWithShips = systems.filter((s) => shipCounts.has(s.symbol));
      const viewSystems = systemsWithShips.length > 0 ? systemsWithShips : systems;

      const avgX = viewSystems.reduce((sum, s) => sum + s.x, 0) / viewSystems.length;
      const avgY = viewSystems.reduce((sum, s) => sum + s.y, 0) / viewSystems.length;

      // Reset container position and pivot
      const canvasWidth = app.canvas.width;
      const canvasHeight = app.canvas.height;

      container.pivot.set(avgX, avgY);
      container.x = canvasWidth / 2;
      container.y = canvasHeight / 2;
      container.scale.set(0.5, 0.5); // Start zoomed out to see galaxy
    }
  }, [systems, ships, currentSystem, setCurrentSystem, setViewMode, container, app]);

  return (
    <div className="relative w-full h-full">
      <div ref={canvasRef} className="w-full h-full" />

      {/* Controls overlay */}
      <div className="absolute top-4 left-4 bg-gray-800 bg-opacity-80 rounded p-3 text-sm">
        <div className="mb-2">
          <strong>Galaxy View</strong>
        </div>
        <div>
          <strong>Systems:</strong> {systems.length}
        </div>
        <div className="mb-3">
          <strong>Ships:</strong> {ships.length}
        </div>
        <div className="text-xs text-gray-400 border-t border-gray-600 pt-2">
          <div>🖱️ Drag to pan</div>
          <div>🔍 Scroll to zoom</div>
          <div>🖱️ Click system to view</div>
        </div>
      </div>

      {/* Loading state */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-gray-800 bg-opacity-90 rounded-lg p-8 text-center">
            <h2 className="text-xl font-bold mb-2">Loading Systems...</h2>
            <p className="text-gray-400">Fetching galaxy data from SpaceTraders API</p>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-gray-800 bg-opacity-80 rounded p-3 text-xs">
        <div className="font-bold mb-2">Legend</div>
        <div className="flex items-center gap-2 mb-1">
          <div className="w-3 h-3 rounded-full bg-[#4ECDC4]" />
          <span>Systems with ships</span>
        </div>
        <div className="flex items-center gap-2 mb-1">
          <div className="w-3 h-3 rounded-full bg-[#666666]" />
          <span>Empty systems</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full border-2 border-[#FFE66D]" />
          <span>Current system</span>
        </div>
      </div>
    </div>
  );
};

export default GalaxyView;
