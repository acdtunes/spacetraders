import { useEffect, useRef } from 'react';
import * as PIXI from 'pixi.js';
import type { Waypoint } from '../types/spacetraders';

interface MinimapProps {
  waypoints: Map<string, Waypoint>;
  viewportBounds: {
    x: number;
    y: number;
    width: number;
    height: number;
    scale: number;
  };
  onNavigate: (x: number, y: number) => void;
}

const Minimap = ({ waypoints, viewportBounds, onNavigate }: MinimapProps) => {
  const canvasRef = useRef<HTMLDivElement>(null);
  const appRef = useRef<PIXI.Application | null>(null);

  // Initialize minimap
  useEffect(() => {
    if (!canvasRef.current || waypoints.size === 0) return;

    let mounted = true;

    (async () => {
      const app = new PIXI.Application();

      await app.init({
        width: 250,
        height: 250,
        backgroundColor: 0x0a0a1a,
        antialias: true,
        autoDensity: true,
        resolution: window.devicePixelRatio || 1,
      });

      if (!mounted) {
        app.destroy(true);
        return;
      }

      if (canvasRef.current) {
        canvasRef.current.appendChild(app.canvas);
      }

      appRef.current = app;
    })();

    return () => {
      mounted = false;
      if (appRef.current) {
        appRef.current.destroy(true);
        appRef.current = null;
      }
    };
  }, []);

  // Render minimap content
  useEffect(() => {
    if (!appRef.current || waypoints.size === 0) return;

    const app = appRef.current;
    const stage = app.stage;

    // Clear previous content
    stage.removeChildren();

    const waypointArray = Array.from(waypoints.values());

    // Calculate bounds
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    waypointArray.forEach(wp => {
      minX = Math.min(minX, wp.x);
      maxX = Math.max(maxX, wp.x);
      minY = Math.min(minY, wp.y);
      maxY = Math.max(maxY, wp.y);
    });

    const width = maxX - minX;
    const height = maxY - minY;
    const padding = 10;

    // Calculate scale to fit minimap
    const scaleX = (app.canvas.width - padding * 2) / width;
    const scaleY = (app.canvas.height - padding * 2) / height;
    const scale = Math.min(scaleX, scaleY);

    // Draw waypoints
    const graphics = new PIXI.Graphics();

    waypointArray.forEach(wp => {
      const x = padding + (wp.x - minX) * scale;
      const y = padding + (wp.y - minY) * scale;

      // Color code by type
      let color = 0x4a9eff;
      if (wp.type === 'JUMP_GATE') color = 0x9b59b6;
      else if (wp.type === 'ORBITAL_STATION') color = 0x3498db;
      else if (wp.type === 'PLANET') color = 0x2980b9;
      else if (wp.type === 'GAS_GIANT') color = 0xe67e22;
      else if (wp.type === 'ASTEROID' || wp.type === 'ASTEROID_FIELD') color = 0x7f8c8d;

      graphics.circle(x, y, 2);
      graphics.fill({ color, alpha: 0.8 });
    });

    stage.addChild(graphics);

    // Draw viewport rectangle
    const viewportGraphics = new PIXI.Graphics();

    const vpCenterX = viewportBounds.x;
    const vpCenterY = viewportBounds.y;
    const vpWidth = viewportBounds.width / viewportBounds.scale;
    const vpHeight = viewportBounds.height / viewportBounds.scale;

    const vpMinX = vpCenterX - vpWidth / 2;
    const vpMinY = vpCenterY - vpHeight / 2;

    const rectX = padding + (vpMinX - minX) * scale;
    const rectY = padding + (vpMinY - minY) * scale;
    const rectWidth = vpWidth * scale;
    const rectHeight = vpHeight * scale;

    // Semi-transparent fill to show viewport area
    viewportGraphics.rect(rectX, rectY, rectWidth, rectHeight);
    viewportGraphics.fill({ color: 0xffaa00, alpha: 0.15 });
    viewportGraphics.rect(rectX, rectY, rectWidth, rectHeight);
    viewportGraphics.stroke({ color: 0xffaa00, width: 2, alpha: 0.9 });

    stage.addChild(viewportGraphics);

    // Make minimap clickable for navigation
    const interactiveArea = new PIXI.Graphics();
    interactiveArea.rect(0, 0, app.canvas.width, app.canvas.height);
    interactiveArea.fill({ color: 0x000000, alpha: 0.001 });
    interactiveArea.eventMode = 'static';
    interactiveArea.cursor = 'pointer';

    interactiveArea.on('click', (e: any) => {
      const localPos = e.data.getLocalPosition(interactiveArea);
      const worldX = minX + (localPos.x - padding) / scale;
      const worldY = minY + (localPos.y - padding) / scale;
      onNavigate(worldX, worldY);
    });

    stage.addChild(interactiveArea);
  }, [waypoints, viewportBounds, onNavigate]);

  if (waypoints.size === 0) return null;

  return (
    <div className="absolute bottom-4 left-4 bg-gray-800 border-2 border-gray-700 rounded-lg shadow-lg overflow-hidden z-10">
      <div className="bg-gray-750 px-2 py-1 border-b border-gray-700">
        <span className="text-xs font-bold">Minimap</span>
      </div>
      <div ref={canvasRef} />
    </div>
  );
};

export default Minimap;
