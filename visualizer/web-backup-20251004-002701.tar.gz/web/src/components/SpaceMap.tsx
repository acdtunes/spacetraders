import { useEffect, useRef, useState, forwardRef, useImperativeHandle } from 'react';
import * as PIXI from 'pixi.js';
import { useStore } from '../store/useStore';
import type { Waypoint } from '../types/spacetraders';
import { getWaypoints } from '../services/api';
import { getWaypointOpportunities, formatOpportunity } from '../services/marketAnalysis';
import { getWaypointRadius, interpolateShipPosition } from '../utils/shipPosition';
import { drawShipShape } from '../services/pixi/ShipRenderer';
import ZoomControls from './ZoomControls';
import Legend from './Legend';
import Minimap from './Minimap';


// Waypoint rendering by type
function drawWaypoint(graphics: PIXI.Graphics, waypoint: Waypoint, x: number, y: number, radius: number) {
  const type = waypoint.type;

  switch (type) {
    case 'PLANET':
      // Determine planet type based on position hash for consistency
      const hash = (x * 73856093) ^ (y * 19349663);
      const planetType = Math.abs(hash) % 6; // 6 planet types now

      if (planetType === 0) {
        // Earth-like planet with oceans and continents
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0x2980b9, alpha: 1.0 }); // Ocean base

        // Multiple continents using smooth circles
        graphics.circle(x - radius * 0.3, y - radius * 0.2, radius * 0.4);
        graphics.fill({ color: 0x27ae60, alpha: 0.85 });

        graphics.circle(x + radius * 0.2, y + radius * 0.35, radius * 0.35);
        graphics.fill({ color: 0x16a085, alpha: 0.85 });

        graphics.circle(x + radius * 0.45, y - radius * 0.35, radius * 0.25);
        graphics.fill({ color: 0x229954, alpha: 0.8 });

        graphics.circle(x - radius * 0.5, y + radius * 0.4, radius * 0.22);
        graphics.fill({ color: 0x1e8449, alpha: 0.8 });

        // Ice caps - smooth
        graphics.circle(x, y - radius * 0.7, radius * 0.22);
        graphics.fill({ color: 0xecf0f1, alpha: 0.9 });

        graphics.circle(x, y + radius * 0.7, radius * 0.2);
        graphics.fill({ color: 0xbdc3c7, alpha: 0.9 });

        // Cloud swirls for atmosphere
        graphics.circle(x - radius * 0.15, y - radius * 0.5, radius * 0.18);
        graphics.fill({ color: 0xffffff, alpha: 0.25 });
        graphics.circle(x + radius * 0.35, y + radius * 0.15, radius * 0.15);
        graphics.fill({ color: 0xffffff, alpha: 0.2 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0x1a5490, width: 1.5, alpha: 0.9 });
      } else if (planetType === 1) {
        // Desert/arid planet - smooth and planet-like
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0xd35400, alpha: 1.0 });

        // Lighter sand regions - smooth circles
        graphics.circle(x - radius * 0.25, y - radius * 0.3, radius * 0.35);
        graphics.fill({ color: 0xe67e22, alpha: 0.7 });

        graphics.circle(x + radius * 0.3, y + radius * 0.25, radius * 0.4);
        graphics.fill({ color: 0xe67e22, alpha: 0.65 });

        graphics.circle(x - radius * 0.4, y + radius * 0.35, radius * 0.25);
        graphics.fill({ color: 0xe67e22, alpha: 0.6 });

        // Dark rocky regions
        graphics.circle(x + radius * 0.35, y - radius * 0.3, radius * 0.2);
        graphics.fill({ color: 0x8b4513, alpha: 0.85 });

        graphics.circle(x - radius * 0.35, y + radius * 0.15, radius * 0.18);
        graphics.fill({ color: 0x654321, alpha: 0.8 });

        // Dust storms - white swirls
        graphics.circle(x + radius * 0.15, y - radius * 0.5, radius * 0.15);
        graphics.fill({ color: 0xffffff, alpha: 0.3 });

        graphics.circle(x - radius * 0.2, y + radius * 0.6, radius * 0.12);
        graphics.fill({ color: 0xffffff, alpha: 0.25 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0xc0392b, width: 1.5, alpha: 0.9 });
      } else if (planetType === 2) {
        // Ice planet
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0xd5f4e6, alpha: 0.95 });

        // Frozen surfaces with irregular ice shelves
        const ice1Points: number[] = [];
        for (let i = 0; i < 10; i++) {
          const angle = (i * Math.PI * 2) / 10;
          const r = radius * (0.3 + Math.sin(i * 1.8) * 0.08);
          ice1Points.push(x - radius * 0.35 + Math.cos(angle) * r, y - radius * 0.25 + Math.sin(angle) * r);
        }
        graphics.poly(ice1Points);
        graphics.fill({ color: 0xa9dfbf, alpha: 0.7 });

        const ice2Points: number[] = [];
        for (let i = 0; i < 12; i++) {
          const angle = (i * Math.PI * 2) / 12;
          const r = radius * (0.35 + Math.cos(i * 2) * 0.1);
          ice2Points.push(x + radius * 0.3 + Math.cos(angle) * r, y + radius * 0.3 + Math.sin(angle) * r);
        }
        graphics.poly(ice2Points);
        graphics.fill({ color: 0x85c1e2, alpha: 0.7 });

        const ice3Points: number[] = [];
        for (let i = 0; i < 8; i++) {
          const angle = (i * Math.PI * 2) / 8;
          const r = radius * (0.22 + Math.sin(i * 2.3) * 0.06);
          ice3Points.push(x + radius * 0.4 + Math.cos(angle) * r, y - radius * 0.4 + Math.sin(angle) * r);
        }
        graphics.poly(ice3Points);
        graphics.fill({ color: 0xaed6f1, alpha: 0.75 });

        const ice4Points: number[] = [];
        for (let i = 0; i < 9; i++) {
          const angle = (i * Math.PI * 2) / 9;
          const r = radius * (0.25 + Math.cos(i * 1.7) * 0.07);
          ice4Points.push(x - radius * 0.45 + Math.cos(angle) * r, y + radius * 0.35 + Math.sin(angle) * r);
        }
        graphics.poly(ice4Points);
        graphics.fill({ color: 0x7fb3d5, alpha: 0.7 });

        // Cracks/crevasses - jagged lines
        const crack1Points: number[] = [];
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI * 2) / 6;
          const r = radius * (0.13 + Math.sin(i * 3) * 0.04);
          crack1Points.push(x + radius * 0.1 + Math.cos(angle) * r, y + Math.sin(angle) * r);
        }
        graphics.poly(crack1Points);
        graphics.fill({ color: 0x5499c7, alpha: 0.6 });

        const crack2Points: number[] = [];
        for (let i = 0; i < 5; i++) {
          const angle = (i * Math.PI * 2) / 5;
          const r = radius * (0.1 + Math.cos(i * 2.2) * 0.03);
          crack2Points.push(x - radius * 0.2 + Math.cos(angle) * r, y - radius * 0.4 + Math.sin(angle) * r);
        }
        graphics.poly(crack2Points);
        graphics.fill({ color: 0x5dade2, alpha: 0.6 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0x3498db, width: 1, alpha: 0.8 });
      } else if (planetType === 3) {
        // Volcanic/lava planet
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0x1c1c1c, alpha: 0.95 }); // Dark crust

        // Lava flows - irregular organic shapes
        const lava1Points: number[] = [];
        for (let i = 0; i < 10; i++) {
          const angle = (i * Math.PI * 2) / 10;
          const r = radius * (0.3 + Math.sin(i * 2.1) * 0.09);
          lava1Points.push(x - radius * 0.3 + Math.cos(angle) * r, y - radius * 0.2 + Math.sin(angle) * r);
        }
        graphics.poly(lava1Points);
        graphics.fill({ color: 0xe74c3c, alpha: 0.8 });

        const lava2Points: number[] = [];
        for (let i = 0; i < 8; i++) {
          const angle = (i * Math.PI * 2) / 8;
          const r = radius * (0.26 + Math.cos(i * 1.8) * 0.08);
          lava2Points.push(x + radius * 0.25 + Math.cos(angle) * r, y + radius * 0.3 + Math.sin(angle) * r);
        }
        graphics.poly(lava2Points);
        graphics.fill({ color: 0xc0392b, alpha: 0.8 });

        const lava3Points: number[] = [];
        for (let i = 0; i < 9; i++) {
          const angle = (i * Math.PI * 2) / 9;
          const r = radius * (0.22 + Math.sin(i * 2.5) * 0.07);
          lava3Points.push(x + radius * 0.4 + Math.cos(angle) * r, y - radius * 0.35 + Math.sin(angle) * r);
        }
        graphics.poly(lava3Points);
        graphics.fill({ color: 0xff6b6b, alpha: 0.75 });

        const lava4Points: number[] = [];
        for (let i = 0; i < 7; i++) {
          const angle = (i * Math.PI * 2) / 7;
          const r = radius * (0.19 + Math.cos(i * 2.2) * 0.06);
          lava4Points.push(x - radius * 0.4 + Math.cos(angle) * r, y + radius * 0.4 + Math.sin(angle) * r);
        }
        graphics.poly(lava4Points);
        graphics.fill({ color: 0xe67e22, alpha: 0.8 });

        // Volcanic vents - irregular bright spots
        const vent1Points: number[] = [];
        for (let i = 0; i < 6; i++) {
          const angle = (i * Math.PI * 2) / 6;
          const r = radius * (0.13 + Math.sin(i * 2.8) * 0.03);
          vent1Points.push(x + Math.cos(angle) * r, y - radius * 0.5 + Math.sin(angle) * r);
        }
        graphics.poly(vent1Points);
        graphics.fill({ color: 0xf39c12, alpha: 0.9 });

        const vent2Points: number[] = [];
        for (let i = 0; i < 5; i++) {
          const angle = (i * Math.PI * 2) / 5;
          const r = radius * (0.1 + Math.cos(i * 2) * 0.03);
          vent2Points.push(x + radius * 0.5 + Math.cos(angle) * r, y + radius * 0.1 + Math.sin(angle) * r);
        }
        graphics.poly(vent2Points);
        graphics.fill({ color: 0xf1c40f, alpha: 0.9 });

        const vent3Points: number[] = [];
        for (let i = 0; i < 5; i++) {
          const angle = (i * Math.PI * 2) / 5;
          const r = radius * (0.08 + Math.sin(i * 1.5) * 0.02);
          vent3Points.push(x - radius * 0.3 + Math.cos(angle) * r, y + radius * 0.5 + Math.sin(angle) * r);
        }
        graphics.poly(vent3Points);
        graphics.fill({ color: 0xffa500, alpha: 0.9 });
      } else if (planetType === 4) {
        // Ocean world with archipelagos
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0x1a5490, alpha: 0.95 }); // Deep ocean

        // Small scattered island chains
        for (let i = 0; i < 10; i++) {
          const angle = (i * Math.PI * 2) / 10;
          const dist = radius * (0.4 + (i % 3) * 0.15);
          const islandX = x + Math.cos(angle) * dist;
          const islandY = y + Math.sin(angle) * dist;

          const islandPoints: number[] = [];
          for (let j = 0; j < 6; j++) {
            const islandAngle = (j * Math.PI * 2) / 6;
            const r = radius * (0.08 + Math.sin(j * 2) * 0.03);
            islandPoints.push(islandX + Math.cos(islandAngle) * r, islandY + Math.sin(islandAngle) * r);
          }
          graphics.poly(islandPoints);
          graphics.fill({ color: 0x27ae60, alpha: 0.8 });
        }

        // Polar ice
        graphics.circle(x, y - radius * 0.75, radius * 0.2);
        graphics.fill({ color: 0xecf0f1, alpha: 0.85 });
        graphics.circle(x, y + radius * 0.75, radius * 0.18);
        graphics.fill({ color: 0xbdc3c7, alpha: 0.85 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0x2980b9, width: 1, alpha: 0.8 });
      } else {
        // Tropical/jungle world
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0x16a085, alpha: 0.9 }); // Greenish base

        // Dense vegetation coverage with varied greens
        const jungle1Points: number[] = [];
        for (let i = 0; i < 14; i++) {
          const angle = (i * Math.PI * 2) / 14;
          const r = radius * (0.55 + Math.sin(i * 1.3) * 0.12);
          jungle1Points.push(x - radius * 0.2 + Math.cos(angle) * r, y - radius * 0.15 + Math.sin(angle) * r);
        }
        graphics.poly(jungle1Points);
        graphics.fill({ color: 0x1e8449, alpha: 0.8 });

        const jungle2Points: number[] = [];
        for (let i = 0; i < 12; i++) {
          const angle = (i * Math.PI * 2) / 12;
          const r = radius * (0.5 + Math.cos(i * 2.2) * 0.13);
          jungle2Points.push(x + radius * 0.25 + Math.cos(angle) * r, y + radius * 0.2 + Math.sin(angle) * r);
        }
        graphics.poly(jungle2Points);
        graphics.fill({ color: 0x229954, alpha: 0.8 });

        const jungle3Points: number[] = [];
        for (let i = 0; i < 10; i++) {
          const angle = (i * Math.PI * 2) / 10;
          const r = radius * (0.42 + Math.sin(i * 1.8) * 0.1);
          jungle3Points.push(x + radius * 0.35 + Math.cos(angle) * r, y - radius * 0.4 + Math.sin(angle) * r);
        }
        graphics.poly(jungle3Points);
        graphics.fill({ color: 0x27ae60, alpha: 0.75 });

        // Small water bodies
        graphics.circle(x - radius * 0.5, y - radius * 0.3, radius * 0.15);
        graphics.fill({ color: 0x3498db, alpha: 0.7 });
        graphics.circle(x + radius * 0.15, y + radius * 0.5, radius * 0.18);
        graphics.fill({ color: 0x2980b9, alpha: 0.7 });
        graphics.circle(x - radius * 0.3, y + radius * 0.45, radius * 0.12);
        graphics.fill({ color: 0x5dade2, alpha: 0.7 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0x117a65, width: 1, alpha: 0.8 });
      }
      break;

    case 'GAS_GIANT':
      graphics.circle(x, y, radius);
      graphics.fill({ color: 0xe67e22, alpha: 0.9 });
      for (let i = -radius * 0.6; i < radius * 0.6; i += radius * 0.3) {
        graphics.rect(x - radius, y + i, radius * 2, radius * 0.15);
        graphics.fill({ color: 0xd35400, alpha: 0.6 });
      }
      graphics.circle(x + radius * 0.3, y, radius * 0.4);
      graphics.fill({ color: 0xc0392b, alpha: 0.7 });
      graphics.circle(x, y, radius * 1.2);
      graphics.stroke({ color: 0xf39c12, width: 1.5, alpha: 0.4 });
      break;

    case 'MOON':
      // Vary moon appearance based on position
      const moonHash = (x * 73856093) ^ (y * 19349663);
      const moonType = Math.abs(moonHash) % 3;

      if (moonType === 0) {
        // Gray rocky moon
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0x95a5a6, alpha: 1.0 });

        // Multiple craters with varied depths
        graphics.circle(x - radius * 0.3, y - radius * 0.2, radius * 0.3);
        graphics.fill({ color: 0x7f8c8d, alpha: 0.9 });

        graphics.circle(x + radius * 0.4, y + radius * 0.1, radius * 0.22);
        graphics.fill({ color: 0x7f8c8d, alpha: 0.85 });

        graphics.circle(x, y + radius * 0.5, radius * 0.26);
        graphics.fill({ color: 0x7f8c8d, alpha: 0.88 });

        graphics.circle(x - radius * 0.5, y + radius * 0.3, radius * 0.18);
        graphics.fill({ color: 0x7f8c8d, alpha: 0.82 });

        graphics.circle(x + radius * 0.2, y - radius * 0.5, radius * 0.2);
        graphics.fill({ color: 0x7f8c8d, alpha: 0.86 });

        // Bright ray crater
        graphics.circle(x - radius * 0.3, y - radius * 0.3, radius * 0.2);
        graphics.fill({ color: 0xbdc3c7, alpha: 0.7 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0x7f8c8d, width: 1.2, alpha: 0.9 });
      } else if (moonType === 1) {
        // Brownish/tan moon
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0xa0826d, alpha: 1.0 });

        // Dark maria (seas)
        graphics.circle(x - radius * 0.25, y - radius * 0.25, radius * 0.35);
        graphics.fill({ color: 0x6d5d4b, alpha: 0.85 });

        graphics.circle(x + radius * 0.3, y + radius * 0.2, radius * 0.38);
        graphics.fill({ color: 0x5c4d3d, alpha: 0.8 });

        // Impact craters
        graphics.circle(x + radius * 0.45, y - radius * 0.35, radius * 0.2);
        graphics.fill({ color: 0x8b7355, alpha: 0.9 });

        graphics.circle(x - radius * 0.4, y + radius * 0.4, radius * 0.18);
        graphics.fill({ color: 0x786450, alpha: 0.88 });

        graphics.circle(x + radius * 0.1, y - radius * 0.5, radius * 0.15);
        graphics.fill({ color: 0x6d5d4b, alpha: 0.85 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0x6d5d4b, width: 1.2, alpha: 0.9 });
      } else {
        // Icy/white moon
        graphics.circle(x, y, radius);
        graphics.fill({ color: 0xd5d8dc, alpha: 1.0 });

        // Darker ice regions
        graphics.circle(x - radius * 0.3, y - radius * 0.2, radius * 0.32);
        graphics.fill({ color: 0xaeb6bf, alpha: 0.85 });

        graphics.circle(x + radius * 0.35, y + radius * 0.25, radius * 0.35);
        graphics.fill({ color: 0xbdc3c7, alpha: 0.8 });

        // Bright craters
        graphics.circle(x + radius * 0.4, y - radius * 0.4, radius * 0.22);
        graphics.fill({ color: 0xecf0f1, alpha: 0.9 });

        graphics.circle(x - radius * 0.45, y + radius * 0.35, radius * 0.2);
        graphics.fill({ color: 0xe8daef, alpha: 0.85 });

        graphics.circle(x - radius * 0.1, y + radius * 0.5, radius * 0.18);
        graphics.fill({ color: 0xf4ecf7, alpha: 0.88 });

        graphics.circle(x, y, radius);
        graphics.stroke({ color: 0xaeb6bf, width: 1.2, alpha: 0.9 });
      }
      break;

    case 'ORBITAL_STATION':
    case 'FUEL_STATION':
      graphics.circle(x, y, radius * 0.6);
      graphics.fill({ color: 0x34495e, alpha: 0.95 });
      graphics.circle(x, y, radius * 0.9);
      graphics.stroke({ color: 0x3498db, width: 1.5, alpha: 0.8 });
      const dockSize = radius * 0.3;
      graphics.rect(x - radius - dockSize, y - dockSize / 2, dockSize, dockSize);
      graphics.fill({ color: 0x2c3e50, alpha: 0.9 });
      graphics.rect(x + radius, y - dockSize / 2, dockSize, dockSize);
      graphics.fill({ color: 0x2c3e50, alpha: 0.9 });
      graphics.rect(x - dockSize / 2, y - radius - dockSize, dockSize, dockSize);
      graphics.fill({ color: 0x2c3e50, alpha: 0.9 });
      graphics.rect(x - dockSize / 2, y + radius, dockSize, dockSize);
      graphics.fill({ color: 0x2c3e50, alpha: 0.9 });
      graphics.circle(x, y, radius * 0.3);
      graphics.fill({ color: type === 'FUEL_STATION' ? 0xf39c12 : 0x3498db, alpha: 0.9 });
      graphics.moveTo(x, y - radius * 0.6);
      graphics.lineTo(x, y - radius * 1.5);
      graphics.stroke({ color: 0xecf0f1, width: 1, alpha: 0.8 });
      graphics.circle(x, y - radius * 1.5, radius * 0.15);
      graphics.fill({ color: 0xff0000, alpha: 0.9 });
      break;

    case 'JUMP_GATE':
      graphics.circle(x, y, radius);
      graphics.stroke({ color: 0x9b59b6, width: 2, alpha: 0.9 });
      graphics.circle(x, y, radius * 0.7);
      graphics.stroke({ color: 0x8e44ad, width: 1.5, alpha: 0.9 });
      for (let i = 0; i < 5; i++) {
        const angle = (i * Math.PI * 2) / 5;
        const r = radius * 0.5;
        graphics.moveTo(x, y);
        graphics.lineTo(x + Math.cos(angle) * r, y + Math.sin(angle) * r);
        graphics.stroke({ color: 0xe74c3c, width: 1, alpha: 0.6 });
      }
      graphics.circle(x, y, radius * 0.3);
      graphics.fill({ color: 0xffffff, alpha: 0.8 });
      break;

    case 'ASTEROID':
    case 'ENGINEERED_ASTEROID':
    case 'ASTEROID_BASE':
      const points: number[] = [];
      // Higher resolution polygon (24 points instead of 8)
      for (let i = 0; i < 24; i++) {
        const angle = (i * Math.PI * 2) / 24;
        const r = radius * (0.7 + Math.random() * 0.3);
        points.push(x + Math.cos(angle) * r, y + Math.sin(angle) * r);
      }
      graphics.poly(points);
      graphics.fill({ color: type === 'ENGINEERED_ASTEROID' ? 0x16a085 : 0x7f8c8d, alpha: 0.9 });
      // More crater details
      graphics.circle(x - radius * 0.2, y, radius * 0.2);
      graphics.fill({ color: 0x5d6d7e, alpha: 0.8 });
      graphics.circle(x + radius * 0.3, y - radius * 0.2, radius * 0.15);
      graphics.fill({ color: 0x5d6d7e, alpha: 0.8 });
      graphics.circle(x + radius * 0.1, y + radius * 0.3, radius * 0.12);
      graphics.fill({ color: 0x5d6d7e, alpha: 0.8 });
      graphics.circle(x - radius * 0.4, y - radius * 0.2, radius * 0.18);
      graphics.fill({ color: 0x5d6d7e, alpha: 0.8 });
      if (type === 'ASTEROID_BASE') {
        graphics.rect(x - radius * 0.4, y + radius * 0.3, radius * 0.8, radius * 0.3);
        graphics.fill({ color: 0x2980b9, alpha: 0.9 });
        graphics.circle(x, y + radius * 0.5, radius * 0.2);
        graphics.fill({ color: 0x3498db, alpha: 0.9 });
      }
      if (type === 'ENGINEERED_ASTEROID') {
        graphics.circle(x - radius * 0.3, y - radius * 0.3, radius * 0.1);
        graphics.fill({ color: 0x00ff00, alpha: 0.9 });
        graphics.circle(x + radius * 0.3, y + radius * 0.2, radius * 0.1);
        graphics.fill({ color: 0x00ff00, alpha: 0.9 });
      }
      break;

    case 'ASTEROID_FIELD':
      for (let i = 0; i < 5; i++) {
        const angle = (i * Math.PI * 2) / 5 + Math.random() * 0.5;
        const distance = radius * 0.6;
        const ax = x + Math.cos(angle) * distance;
        const ay = y + Math.sin(angle) * distance;
        const ar = radius * 0.2;
        graphics.circle(ax, ay, ar);
        graphics.fill({ color: 0x7f8c8d, alpha: 0.8 });
      }
      graphics.circle(x, y, radius * 0.15);
      graphics.fill({ color: 0xecf0f1, alpha: 0.6 });
      break;

    case 'DEBRIS_FIELD':
      for (let i = 0; i < 8; i++) {
        const angle = Math.random() * Math.PI * 2;
        const distance = Math.random() * radius;
        const dx = x + Math.cos(angle) * distance;
        const dy = y + Math.sin(angle) * distance;
        const size = radius * 0.1;
        graphics.rect(dx - size / 2, dy - size / 2, size, size);
        graphics.fill({ color: 0x95a5a6, alpha: 0.7 });
      }
      graphics.circle(x, y, radius * 0.2);
      graphics.stroke({ color: 0xe74c3c, width: 1.5, alpha: 0.8 });
      break;

    case 'NEBULA':
      for (let i = 0; i < 3; i++) {
        const offset = radius * 0.3 * (i - 1);
        graphics.circle(x + offset, y, radius * 0.8);
        graphics.fill({ color: 0xe74c3c, alpha: 0.3 });
      }
      graphics.circle(x, y, radius * 0.5);
      graphics.fill({ color: 0xff6b9d, alpha: 0.5 });
      break;

    case 'GRAVITY_WELL':
    case 'ARTIFICIAL_GRAVITY_WELL':
      for (let i = 1; i <= 3; i++) {
        graphics.circle(x, y, radius * i * 0.4);
        graphics.stroke({ color: 0x8e44ad, width: 1, alpha: 0.6 / i });
      }
      graphics.circle(x, y, radius * 0.3);
      graphics.fill({ color: type === 'ARTIFICIAL_GRAVITY_WELL' ? 0x3498db : 0x000000, alpha: 0.95 });
      for (let i = 0; i < 6; i++) {
        const angle = (i * Math.PI * 2) / 6;
        graphics.moveTo(x, y);
        graphics.lineTo(x + Math.cos(angle) * radius * 0.25, y + Math.sin(angle) * radius * 0.25);
        graphics.stroke({ color: 0xe74c3c, width: 0.5, alpha: 0.7 });
      }
      break;

    default:
      graphics.circle(x, y, radius);
      graphics.fill({ color: 0xffffff, alpha: 0.7 });
      graphics.circle(x, y, radius);
      graphics.stroke({ color: 0xecf0f1, width: 1, alpha: 0.8 });
  }
}

export interface SpaceMapRef {
  zoomIn: () => void;
  zoomOut: () => void;
  resetView: () => void;
  fitView: () => void;
  focusOn: (x: number, y: number) => void;
}

const SpaceMap = forwardRef<SpaceMapRef>((props, ref) => {
  const canvasRef = useRef<HTMLDivElement>(null);
  const appRef = useRef<PIXI.Application | null>(null);
  const containerRef = useRef<PIXI.Container | null>(null);
  const waypointsSizeRef = useRef<number>(0);

  const { currentSystem, waypoints, ships, markets, showMarkets, setWaypoints, showLabels, addTrailPosition, trails, agents, filterStatus, filterAgents, filterWaypointTypes, setSelectedShip, setSelectedWaypoint } =
    useStore();

  const [hoveredWaypoint, setHoveredWaypoint] = useState<string | null>(null);
  const [mousePosition, setMousePosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [selectedObject, setSelectedObject] = useState<{ type: 'waypoint' | 'ship', symbol: string, x: number, y: number } | null>(null);
  const [viewportBounds, setViewportBounds] = useState({ x: 0, y: 0, width: 0, height: 0, scale: 1 });
  const selectionMarkerRef = useRef<PIXI.Graphics | null>(null);
  const selectionInfoRef = useRef<PIXI.Container | null>(null);

  // Update viewport bounds for minimap
  const updateViewportBounds = () => {
    if (!containerRef.current || !appRef.current) return;
    const container = containerRef.current;
    const app = appRef.current;

    // Calculate world position at center of screen
    const screenCenterX = app.canvas.width / 2;
    const screenCenterY = app.canvas.height / 2;
    const worldX = (screenCenterX - container.x) / container.scale.x;
    const worldY = (screenCenterY - container.y) / container.scale.y;

    setViewportBounds({
      x: worldX,
      y: worldY,
      width: app.canvas.width,
      height: app.canvas.height,
      scale: container.scale.x,
    });
  };

  // Handle minimap navigation
  const handleMinimapNavigate = (worldX: number, worldY: number) => {
    if (!containerRef.current || !appRef.current) return;
    const container = containerRef.current;
    const app = appRef.current;

    container.x = app.canvas.width / 2 - worldX * container.scale.x;
    container.y = app.canvas.height / 2 - worldY * container.scale.y;

    updateViewportBounds();
  };

  // Calculate the center of the densest waypoint cluster
  const calculateClusterCenter = (): { x: number; y: number } => {
    if (waypoints.size === 0) return { x: 0, y: 0 };

    const waypointArray = Array.from(waypoints.values());
    const CLUSTER_RADIUS = 50;
    let maxDensity = 0;
    let clusterCenter = { x: 0, y: 0 };

    waypointArray.forEach(waypoint => {
      const neighbors = waypointArray.filter(w => {
        const dx = w.x - waypoint.x;
        const dy = w.y - waypoint.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        return distance <= CLUSTER_RADIUS;
      });

      if (neighbors.length > maxDensity) {
        maxDensity = neighbors.length;
        const centerX = neighbors.reduce((sum, w) => sum + w.x, 0) / neighbors.length;
        const centerY = neighbors.reduce((sum, w) => sum + w.y, 0) / neighbors.length;
        clusterCenter = { x: centerX, y: centerY };
      }
    });

    return clusterCenter;
  };

  // Zoom control functions
  const handleZoomIn = () => {
    if (!containerRef.current || !appRef.current) return;
    const container = containerRef.current;
    const app = appRef.current;
    const zoomFactor = 1.1;
    const oldScale = container.scale.x;
    const newScale = Math.min(10, oldScale * zoomFactor);
    const scaleDelta = newScale / oldScale;
    const centerX = app.canvas.width / 2;
    const centerY = app.canvas.height / 2;
    const dx = centerX - container.x;
    const dy = centerY - container.y;
    container.scale.set(newScale, newScale);
    container.x = centerX - dx * scaleDelta;
    container.y = centerY - dy * scaleDelta;
    updateViewportBounds();
  };

  const handleZoomOut = () => {
    if (!containerRef.current || !appRef.current) return;
    const container = containerRef.current;
    const app = appRef.current;
    const zoomFactor = 0.9;
    const oldScale = container.scale.x;
    const newScale = Math.max(0.1, oldScale * zoomFactor);
    const scaleDelta = newScale / oldScale;
    const centerX = app.canvas.width / 2;
    const centerY = app.canvas.height / 2;
    const dx = centerX - container.x;
    const dy = centerY - container.y;
    container.scale.set(newScale, newScale);
    container.x = centerX - dx * scaleDelta;
    container.y = centerY - dy * scaleDelta;
    updateViewportBounds();
  };

  const handleResetView = () => {
    if (!containerRef.current || !appRef.current) return;
    const container = containerRef.current;
    const app = appRef.current;

    // Center on the densest cluster
    const clusterCenter = calculateClusterCenter();
    container.x = app.canvas.width / 2 - clusterCenter.x;
    container.y = app.canvas.height / 2 - clusterCenter.y;
    container.scale.set(1, 1);
    updateViewportBounds();
  };

  const handleFitView = () => {
    if (!containerRef.current || !appRef.current || waypoints.size === 0) return;
    const container = containerRef.current;
    const app = appRef.current;

    // Calculate bounds of all waypoints
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    waypoints.forEach(waypoint => {
      minX = Math.min(minX, waypoint.x);
      maxX = Math.max(maxX, waypoint.x);
      minY = Math.min(minY, waypoint.y);
      maxY = Math.max(maxY, waypoint.y);
    });

    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    const width = maxX - minX;
    const height = maxY - minY;

    // Calculate scale to fit with padding
    const padding = 50;
    const scaleX = (app.canvas.width - padding * 2) / width;
    const scaleY = (app.canvas.height - padding * 2) / height;
    const scale = Math.min(scaleX, scaleY, 2); // Cap at 2x zoom

    container.scale.set(scale, scale);
    container.x = app.canvas.width / 2 - centerX * scale;
    container.y = app.canvas.height / 2 - centerY * scale;
    updateViewportBounds();
  };

  const handleFocusOn = (x: number, y: number) => {
    if (!containerRef.current || !appRef.current) return;
    const container = containerRef.current;
    const app = appRef.current;

    // Center the view on the specified coordinates
    const currentScale = container.scale.x;
    container.x = app.canvas.width / 2 - x * currentScale;
    container.y = app.canvas.height / 2 - y * currentScale;
    updateViewportBounds();
  };

  // Expose zoom functions via ref
  useImperativeHandle(ref, () => ({
    zoomIn: handleZoomIn,
    zoomOut: handleZoomOut,
    resetView: handleResetView,
    fitView: handleFitView,
    focusOn: handleFocusOn,
  }));

  // Keyboard handler for deselection
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && selectedObject) {
        setSelectedObject(null);
        setSelectedShip(null);
        setSelectedWaypoint(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedObject]);

  // Initialize PixiJS
  useEffect(() => {
    if (!canvasRef.current) return;

    let mounted = true;

    (async () => {
      const app = new PIXI.Application();

      await app.init({
        width: window.innerWidth - 256, // Subtract sidebar width
        height: window.innerHeight - 64, // Subtract header height
        backgroundColor: 0x000822,
        antialias: true,
        autoDensity: true,
        resolution: window.devicePixelRatio || 1,
      });

      if (!mounted) {
        app.destroy(true);
        return;
      }

      if (canvasRef.current) {
        canvasRef.current.appendChild(app.canvas);
      }

      const container = new PIXI.Container();
      app.stage.addChild(container);
      containerRef.current = container;
      appRef.current = app;

      // Initialize container - pivot always at (0,0), only use position and scale
      container.pivot.set(0, 0);
      container.x = app.canvas.width / 2;
      container.y = app.canvas.height / 2;

      // Pan and zoom state
      let isDragging = false;
      let dragStart = { x: 0, y: 0 };

      // Mouse wheel zoom centered on screen center
      const handleWheel = (e: WheelEvent) => {
        e.preventDefault();
        const zoomFactor = e.deltaY > 0 ? 0.95 : 1.05;
        const oldScale = container.scale.x;
        const newScale = Math.max(0.1, Math.min(10, oldScale * zoomFactor));
        const scaleDelta = newScale / oldScale;

        // Screen center point
        const centerX = app.canvas.width / 2;
        const centerY = app.canvas.height / 2;

        // Calculate position adjustment to keep center fixed
        // The distance from container to screen center scales with zoom
        const dx = centerX - container.x;
        const dy = centerY - container.y;

        // Update scale
        container.scale.set(newScale, newScale);

        // Adjust position - move container by the difference in scaled distance
        container.x = centerX - dx * scaleDelta;
        container.y = centerY - dy * scaleDelta;

        updateViewportBounds();
      };

      // Mouse drag pan
      const handleMouseDown = (e: MouseEvent) => {
        isDragging = true;
        dragStart = { x: e.clientX - container.x, y: e.clientY - container.y };
      };

      const handleMouseMove = (e: MouseEvent) => {
        // Track mouse position for tooltips
        setMousePosition({ x: e.clientX, y: e.clientY });

        if (!isDragging) return;
        container.x = e.clientX - dragStart.x;
        container.y = e.clientY - dragStart.y;
      };

      const handleMouseUp = () => {
        if (isDragging) {
          updateViewportBounds();
        }
        isDragging = false;
      };

      // Handle window resize
      const handleResize = () => {
        if (appRef.current) {
          appRef.current.renderer.resize(window.innerWidth - 256, window.innerHeight - 64);
        }
      };

      app.canvas.addEventListener('wheel', handleWheel);
      app.canvas.addEventListener('mousedown', handleMouseDown);
      app.canvas.addEventListener('mousemove', handleMouseMove);
      app.canvas.addEventListener('mouseup', handleMouseUp);
      app.canvas.addEventListener('mouseleave', handleMouseUp);
      window.addEventListener('resize', handleResize);
    })();

    return () => {
      mounted = false;
      if (appRef.current) {
        appRef.current.destroy(true);
        appRef.current = null;
      }
    };
  }, []);

  // Load waypoints when system changes
  useEffect(() => {
    if (!currentSystem) return;

    getWaypoints(currentSystem)
      .then((data) => {
        setWaypoints(data);
      })
      .catch((error) => {
        console.error('Failed to load waypoints:', error);
      });
  }, [currentSystem, setWaypoints]);

  // Render waypoints
  useEffect(() => {
    if (!containerRef.current || waypoints.size === 0) return;

    const container = containerRef.current;
    // Remove only waypoint graphics, preserve ships and other elements
    container.children.filter(child => child.label === 'waypoint' || child.label === 'waypointLabel').forEach(child => {
      container.removeChild(child);
    });

    // Add coordinate grid
    const gridGraphics = new PIXI.Graphics();
    gridGraphics.label = 'waypoint';

    if (waypoints.size > 0) {
      // Calculate bounds from waypoints
      const waypointArray = Array.from(waypoints.values());
      let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
      waypointArray.forEach(wp => {
        minX = Math.min(minX, wp.x);
        maxX = Math.max(maxX, wp.x);
        minY = Math.min(minY, wp.y);
        maxY = Math.max(maxY, wp.y);
      });

      // Add padding and round to grid spacing
      const GRID_SPACING = 50;
      const padding = GRID_SPACING * 2;
      minX = Math.floor((minX - padding) / GRID_SPACING) * GRID_SPACING;
      maxX = Math.ceil((maxX + padding) / GRID_SPACING) * GRID_SPACING;
      minY = Math.floor((minY - padding) / GRID_SPACING) * GRID_SPACING;
      maxY = Math.ceil((maxY + padding) / GRID_SPACING) * GRID_SPACING;

      // Draw vertical grid lines
      for (let x = minX; x <= maxX; x += GRID_SPACING) {
        gridGraphics.moveTo(x, minY);
        gridGraphics.lineTo(x, maxY);
        gridGraphics.stroke({
          color: x === 0 ? 0x444444 : 0x222222,
          width: x === 0 ? 1.5 : 0.5,
          alpha: x === 0 ? 0.5 : 0.2
        });

        // Add coordinate label every 100 units
        if (x % 100 === 0) {
          const label = new PIXI.Text(x.toString(), {
            fontSize: 8,
            fill: 0x666666,
          });
          label.x = x + 2;
          label.y = 5;
          label.alpha = 0.6;
          label.label = 'waypoint';
          container.addChild(label);
        }
      }

      // Draw horizontal grid lines
      for (let y = minY; y <= maxY; y += GRID_SPACING) {
        gridGraphics.moveTo(minX, y);
        gridGraphics.lineTo(maxX, y);
        gridGraphics.stroke({
          color: y === 0 ? 0x444444 : 0x222222,
          width: y === 0 ? 1.5 : 0.5,
          alpha: y === 0 ? 0.5 : 0.2
        });

        // Add coordinate label every 100 units
        if (y % 100 === 0 && y !== 0) { // Skip 0 to avoid overlap with x-axis label
          const label = new PIXI.Text(y.toString(), {
            fontSize: 8,
            fill: 0x666666,
          });
          label.x = 5;
          label.y = y + 2;
          label.alpha = 0.6;
          label.label = 'waypoint';
          container.addChild(label);
        }
      }

      container.addChild(gridGraphics);
    }

    const graphics = new PIXI.Graphics();

    // Track positions to detect overlaps
    const positionMap = new Map<string, number>();

    // Draw waypoints
    waypoints.forEach((waypoint) => {
      // Filter by waypoint type
      if (!filterWaypointTypes.has(waypoint.type)) {
        return;
      }

      // Calculate size based on type
      const radius = getWaypointRadius(waypoint);

      // Handle overlapping waypoints by offsetting them
      let x = waypoint.x;
      let y = waypoint.y;
      const posKey = `${waypoint.x},${waypoint.y}`;
      const overlapCount = positionMap.get(posKey) || 0;

      if (overlapCount > 0) {
        // Spread overlapping waypoints in a circle
        const angle = (overlapCount * Math.PI * 2) / 8; // Up to 8 overlaps
        const offset = 15 * overlapCount; // Increase distance for each overlap
        x += Math.cos(angle) * offset;
        y += Math.sin(angle) * offset;
      }

      positionMap.set(posKey, overlapCount + 1);

      // Check if waypoint has marketplace
      const hasMarketplace = waypoint.traits.some((t) => t.symbol === 'MARKETPLACE');

      // Draw marketplace indicator if applicable and showMarkets is enabled
      if (hasMarketplace && showMarkets) {
        const ringRadius = radius + 4;

        // Subtle golden ring
        graphics.circle(x, y, ringRadius);
        graphics.stroke({ color: 0xf39c12, width: 1, alpha: 0.6 });
      }

      // Draw waypoint with texture
      drawWaypoint(graphics, waypoint, x, y, radius);

      // Make all waypoints interactive for selection
      const interactiveCircle = new PIXI.Graphics();
      interactiveCircle.circle(0, 0, radius + 20); // Larger hit area
      interactiveCircle.fill({ color: 0x000000, alpha: 0.001 }); // Invisible but interactive
      interactiveCircle.x = x;
      interactiveCircle.y = y;
      interactiveCircle.eventMode = 'static';
      interactiveCircle.cursor = 'pointer';
      interactiveCircle.label = 'waypoint';

      // Enable hover for all waypoints
      interactiveCircle.on('pointerover', () => setHoveredWaypoint(waypoint.symbol));
      interactiveCircle.on('pointerout', () => setHoveredWaypoint(null));

      interactiveCircle.on('click', (e: any) => {
        if (e.stopPropagation) e.stopPropagation();
        if (e.nativeEvent?.stopPropagation) e.nativeEvent.stopPropagation();
        setSelectedObject({ type: 'waypoint', symbol: waypoint.symbol, x: waypoint.x, y: waypoint.y });
        setSelectedWaypoint(waypoint);
        setSelectedShip(null);
      });

      container.addChild(interactiveCircle);

      // Add $ symbol for marketplace waypoints
      if (hasMarketplace && showMarkets) {
        const ringRadius = radius + 4;
        const dollarSign = new PIXI.Text('$', {
          fontSize: 8,
          fill: 0xf39c12,
          fontWeight: 'normal',
        });
        dollarSign.x = x + ringRadius * 0.7 - 3;
        dollarSign.y = y - ringRadius * 0.7 - 4;
        dollarSign.label = 'waypoint';
        container.addChild(dollarSign);
      }

      // Add waypoint label
      const label = new PIXI.Text(waypoint.symbol.split('-').pop() || '', {
        fontSize: 10,
        fill: 0xffffff,
      });
      label.alpha = 0.6;
      label.x = x + radius + 2;
      label.y = y - 5;
      label.label = 'waypointLabel';
      container.addChild(label);
    });

    graphics.label = 'waypoint';
    container.addChild(graphics);

    // Center view on densest waypoint cluster when loading new system (waypoints size changes)
    const waypointsSizeChanged = waypointsSizeRef.current !== waypoints.size;
    if (waypointsSizeChanged && waypoints.size > 0 && appRef.current) {
      const waypointArray = Array.from(waypoints.values());

      // Find the densest cluster by finding the waypoint with most neighbors
      const CLUSTER_RADIUS = 50; // Distance to consider neighbors
      let maxDensity = 0;
      let clusterCenter = { x: 0, y: 0 };

      waypointArray.forEach(waypoint => {
        // Count neighbors within radius
        const neighbors = waypointArray.filter(w => {
          const dx = w.x - waypoint.x;
          const dy = w.y - waypoint.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          return distance <= CLUSTER_RADIUS;
        });

        if (neighbors.length > maxDensity) {
          maxDensity = neighbors.length;
          // Calculate center of this dense cluster
          const centerX = neighbors.reduce((sum, w) => sum + w.x, 0) / neighbors.length;
          const centerY = neighbors.reduce((sum, w) => sum + w.y, 0) / neighbors.length;
          clusterCenter = { x: centerX, y: centerY };
        }
      });

      // Reset container position for new system
      const canvasWidth = appRef.current.canvas.width;
      const canvasHeight = appRef.current.canvas.height;

      // Center on the densest cluster
      // With pivot at (0,0) and scale 1, to show world point (clusterCenter) at screen center:
      // centerX = container.x + clusterCenter.x * 1
      // container.x = centerX - clusterCenter.x
      container.pivot.set(0, 0);
      container.x = canvasWidth / 2 - clusterCenter.x;
      container.y = canvasHeight / 2 - clusterCenter.y;
      container.scale.set(1, 1); // Reset zoom to 1x when loading new system

      waypointsSizeRef.current = waypoints.size;
    }
  }, [waypoints, showMarkets, filterWaypointTypes]);

  // Render ships with animation
  useEffect(() => {
    if (!containerRef.current || !appRef.current) return;

    if (ships.length === 0 || waypoints.size === 0 || !currentSystem) return;

    const container = containerRef.current;
    const app = appRef.current;

    // Remove old ship graphics (keep waypoint graphics)
    const toRemove = container.children.filter((child) => child.label === 'ship');
    toRemove.forEach((child) => container.removeChild(child));

    // Filter ships: only show ships in the current system
    const filteredShips = ships.filter((ship: any) => {
      // Check if ship is in current system
      if (ship.nav.systemSymbol !== currentSystem) return false;

      // Check status filter
      if (!filterStatus.has(ship.nav.status)) return false;

      // Check agent filter (if filterAgents has items, exclude those agents)
      if (ship.agentId && filterAgents.has(ship.agentId)) return false;

      return true;
    });

    // Render ship trails
    filteredShips.forEach((ship: any) => {
      const trail = trails.get(ship.symbol);
      if (!trail || trail.length < 2) return; // Need at least 2 points for a trail

      const shipColor = ship.agentColor ? parseInt(ship.agentColor.replace('#', ''), 16) : 0xff6b6b;

      const trailGraphics = new PIXI.Graphics();
      trailGraphics.label = 'ship';

      // Draw trail line through all positions
      for (let i = 0; i < trail.length - 1; i++) {
        const alpha = (i + 1) / trail.length; // Fade out older positions
        const width = 1 + (i / trail.length) * 1.5; // Thicker at newer positions

        trailGraphics.moveTo(trail[i].x, trail[i].y);
        trailGraphics.lineTo(trail[i + 1].x, trail[i + 1].y);
        trailGraphics.stroke({ color: shipColor, width, alpha: alpha * 0.4 });
      }

      container.addChild(trailGraphics);
    });

    // Render connection lines from ships to destinations
    filteredShips.forEach((ship: any) => {
      if (ship.nav.status !== 'IN_TRANSIT' || !ship.nav.route?.destination) return;

      const position = interpolateShipPosition(ship, waypoints);
      const dest = ship.nav.route.destination;

      if (!dest.x || !dest.y || (position.x === 0 && position.y === 0)) return;

      const shipColor = ship.agentColor ? parseInt(ship.agentColor.replace('#', ''), 16) : 0xff6b6b;

      const connectionLine = new PIXI.Graphics();
      connectionLine.label = 'ship';

      // Draw dashed line to destination
      const dx = dest.x - position.x;
      const dy = dest.y - position.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      const segments = Math.floor(distance / 10); // Dash every 10 units

      for (let i = 0; i < segments; i += 2) {
        const t1 = i / segments;
        const t2 = Math.min((i + 1) / segments, 1);
        const x1 = position.x + dx * t1;
        const y1 = position.y + dy * t1;
        const x2 = position.x + dx * t2;
        const y2 = position.y + dy * t2;

        connectionLine.moveTo(x1, y1);
        connectionLine.lineTo(x2, y2);
        connectionLine.stroke({ color: shipColor, width: 1, alpha: 0.3 });
      }

      container.addChild(connectionLine);
    });

    // Create ship graphics
    const shipGraphicsMap = new Map<string, PIXI.Graphics>();
    const labelContainersMap = new Map<string, PIXI.Container>();
    const routeLabelMap = new Map<string, PIXI.Text>();
    const statusLabelMap = new Map<string, PIXI.Text>();
    const laserGraphicsMap = new Map<string, PIXI.Graphics[]>();

    filteredShips.forEach((ship: any) => {
      const position = interpolateShipPosition(ship, waypoints);

      // Skip if position is invalid
      if (position.x === 0 && position.y === 0) return;

      // Use agent color from tagged ship data
      const shipColor = ship.agentColor ? parseInt(ship.agentColor.replace('#', ''), 16) : 0xff6b6b;

      // Create ship vector drawing
      const shipGraphics = new PIXI.Graphics();

      // Draw ship shape based on role
      drawShipShape(shipGraphics, ship.registration.role, shipColor);

      // Rotate ship based on status
      if (ship.nav.status === 'IN_TRANSIT' && ship.nav.route?.destination) {
        // IN_TRANSIT ships point toward destination
        const dest = ship.nav.route.destination;
        if (dest.x && dest.y) {
          const angle = Math.atan2(dest.y - position.y, dest.x - position.x);
          shipGraphics.rotation = angle + Math.PI / 2; // Add 90° to point ship forward
        }
      } else if (ship.nav.status === 'IN_ORBIT') {
        // IN_ORBIT ships face direction of orbital movement (tangent to orbit)
        const waypointSymbol = ship.nav.waypointSymbol;
        const waypoint = waypoints.get(waypointSymbol);
        if (waypoint) {
          const dx = position.x - waypoint.x;
          const dy = position.y - waypoint.y;
          const orbitalAngle = Math.atan2(dy, dx);
          shipGraphics.rotation = orbitalAngle + Math.PI; // Face forward in orbit direction
        }
      }

      shipGraphics.x = position.x;
      shipGraphics.y = position.y;
      shipGraphics.label = 'ship';

      // Create larger invisible hitbox for easier selection
      const shipHitbox = new PIXI.Graphics();
      shipHitbox.circle(0, 0, 25); // Larger hit area
      shipHitbox.fill({ color: 0x000000, alpha: 0.001 });
      shipHitbox.eventMode = 'static';
      shipHitbox.cursor = 'pointer';
      shipHitbox.label = 'ship';
      shipHitbox.on('click', (e: any) => {
        if (e.stopPropagation) e.stopPropagation();
        if (e.nativeEvent?.stopPropagation) e.nativeEvent.stopPropagation();
        setSelectedObject({ type: 'ship', symbol: ship.symbol, x: position.x, y: position.y });
        setSelectedShip(ship);
        setSelectedWaypoint(null);
      });
      shipGraphics.addChild(shipHitbox);

      container.addChild(shipGraphics);
      shipGraphicsMap.set(ship.symbol, shipGraphics);

      // Add mining laser animation if ship is mining
      if (ship.cooldown && ship.cooldown.remainingSeconds > 0) {
        const waypoint = waypoints.get(ship.nav.waypointSymbol);
        if (waypoint) {
          const lasers: PIXI.Graphics[] = [];
          // Create 3 laser beams with slight offsets
          for (let i = 0; i < 3; i++) {
            const laser = new PIXI.Graphics();
            laser.label = 'ship';
            lasers.push(laser);
            container.addChild(laser);
          }
          laserGraphicsMap.set(ship.symbol, lasers);
        }
      }

      // Add ship label if enabled
      if (showLabels) {
        // Create container for label to position elements
        const labelContainer = new PIXI.Container();
        labelContainer.x = position.x + 8;
        labelContainer.y = position.y - 22;
        labelContainer.label = 'ship';

        let yOffset = 4; // Top margin

        // Ship name (smaller, white)
        const nameLabel = new PIXI.Text(ship.symbol, {
          fontSize: 8,
          fill: 0xffffff,
          fontWeight: '600',
        });
        nameLabel.x = 4;
        nameLabel.y = yOffset;
        yOffset += nameLabel.height + 1;

        // Status line (smaller, colored)
        let status = ship.nav.status.replace('_', ' ');
        // Add mining indicator if ship has active cooldown
        if (ship.cooldown && ship.cooldown.remainingSeconds > 0) {
          status += ' ⛏️';
        }
        const statusLabel = new PIXI.Text(status, {
          fontSize: 7,
          fill: 0x88ccff,
        });
        statusLabel.x = 4;
        statusLabel.y = yOffset;
        yOffset += statusLabel.height + 1;
        statusLabelMap.set(ship.symbol, statusLabel);

        // If in transit, show route with ETA
        let routeLabel = null;
        if (ship.nav.status === 'IN_TRANSIT' && ship.nav.route) {
          const origin = ship.nav.route.origin.symbol.split('-').pop();
          const dest = ship.nav.route.destination.symbol.split('-').pop();

          // Calculate ETA in hh:mm:ss format
          const arrivalTime = new Date(ship.nav.route.arrival).getTime();
          const now = Date.now();
          const remainingMs = Math.max(0, arrivalTime - now);
          const totalSeconds = Math.floor(remainingMs / 1000);
          const hours = Math.floor(totalSeconds / 3600);
          const minutes = Math.floor((totalSeconds % 3600) / 60);
          const seconds = totalSeconds % 60;
          const etaText = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

          routeLabel = new PIXI.Text(`${origin}→${dest} (${etaText})`, {
            fontSize: 7,
            fill: 0xaaaaaa,
          });
          routeLabel.x = 4;
          routeLabel.y = yOffset;
          yOffset += routeLabel.height + 2;

          routeLabelMap.set(ship.symbol, routeLabel);
        }

        // Flight mode
        const flightModeLabel = new PIXI.Text(ship.nav.flightMode, {
          fontSize: 6,
          fill: 0x888888,
        });
        flightModeLabel.x = 4;
        flightModeLabel.y = yOffset;
        yOffset += flightModeLabel.height + 1;

        // Fuel and cargo on separate lines with smaller font
        const fuelText = `⛽ ${ship.fuel.current}/${ship.fuel.capacity}`;
        const cargoText = `📦 ${ship.cargo.units}/${ship.cargo.capacity}`;

        // Fuel label (smaller)
        const fuelLabel = new PIXI.Text(fuelText, {
          fontSize: 7,
          fill: 0x999999,
        });
        fuelLabel.x = 4;
        fuelLabel.y = yOffset;
        yOffset += fuelLabel.height + 1;

        // Cargo label (smaller)
        const cargoLabel = new PIXI.Text(cargoText, {
          fontSize: 7,
          fill: 0x999999,
        });
        cargoLabel.x = 4;
        cargoLabel.y = yOffset;
        yOffset += cargoLabel.height + 4; // Bottom margin

        // Calculate total dimensions
        const allLabels = [nameLabel, statusLabel, routeLabel, fuelLabel, cargoLabel].filter(Boolean);
        const maxWidth = Math.max(...allLabels.map(l => l!.width));
        const totalWidth = maxWidth + 8;
        const totalHeight = yOffset;

        // Create background with border
        const labelBg = new PIXI.Graphics();
        labelBg.rect(0, 0, totalWidth, totalHeight);
        labelBg.fill({ color: 0x1a1a1a, alpha: 0.85 });
        const borderColor = ship.agentColor ? parseInt(ship.agentColor.replace('#', ''), 16) : 0x555555;
        labelBg.stroke({ color: borderColor, width: 1, alpha: 0.6 });

        // Draw connector line from ship to label
        const connectorLine = new PIXI.Graphics();
        // Ship is at position (-8, 22) relative to label container
        // Connect to middle of label box
        connectorLine.moveTo(-8, 22);
        connectorLine.lineTo(0, totalHeight / 2);
        connectorLine.stroke({ color: borderColor, width: 1, alpha: 0.5 });

        // Add all to container
        labelContainer.addChild(connectorLine);
        labelContainer.addChild(labelBg);
        labelContainer.addChild(nameLabel);
        labelContainer.addChild(statusLabel);
        if (routeLabel) labelContainer.addChild(routeLabel);
        labelContainer.addChild(flightModeLabel);
        labelContainer.addChild(fuelLabel);
        labelContainer.addChild(cargoLabel);

        container.addChild(labelContainer);
        labelContainersMap.set(ship.symbol, labelContainer);
      }
    });

    // Animate ships in real-time using ticker
    let lastEtaUpdate = Date.now();
    const ticker = () => {
      const now = Date.now();
      const shouldUpdateEta = now - lastEtaUpdate >= 1000; // Update ETA every second
      if (shouldUpdateEta) lastEtaUpdate = now;

      filteredShips.forEach((ship: any) => {
        const shipGraphic = shipGraphicsMap.get(ship.symbol);
        if (!shipGraphic) return;

        // Recalculate position in real-time
        const position = interpolateShipPosition(ship, waypoints);
        if (position.x === 0 && position.y === 0) return;

        shipGraphic.x = position.x;
        shipGraphic.y = position.y;

        // Update label position if it exists
        const labelContainer = labelContainersMap.get(ship.symbol);
        if (labelContainer) {
          labelContainer.x = position.x + 8;
          labelContainer.y = position.y - 22;
        }

        // Update ETA in route label every second
        if (shouldUpdateEta && ship.nav.status === 'IN_TRANSIT' && ship.nav.route) {
          const routeLabel = routeLabelMap.get(ship.symbol);
          if (routeLabel) {
            const origin = ship.nav.route.origin.symbol.split('-').pop();
            const dest = ship.nav.route.destination.symbol.split('-').pop();
            const arrivalTime = new Date(ship.nav.route.arrival).getTime();
            const remainingMs = Math.max(0, arrivalTime - now);
            const totalSeconds = Math.floor(remainingMs / 1000);
            const hours = Math.floor(totalSeconds / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const seconds = totalSeconds % 60;
            const etaText = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            routeLabel.text = `${origin}→${dest} (${etaText})`;
          }
        }

        // Update status label for mining indicator
        if (shouldUpdateEta) {
          const statusLabel = statusLabelMap.get(ship.symbol);
          if (statusLabel) {
            let status = ship.nav.status.replace('_', ' ');
            if (ship.cooldown && ship.cooldown.remainingSeconds > 0) {
              status += ' ⛏️';
            }
            statusLabel.text = status;
          }

          // Add trail position every second (only for moving ships)
          if (ship.nav.status === 'IN_TRANSIT') {
            addTrailPosition(ship.symbol, {
              shipSymbol: ship.symbol,
              x: position.x,
              y: position.y,
              timestamp: now,
            });
          }
        }

        // Update selection marker and info box if this ship is selected
        if (selectedObject && selectedObject.type === 'ship' && selectedObject.symbol === ship.symbol) {
          if (selectionMarkerRef.current) {
            selectionMarkerRef.current.x = position.x;
            selectionMarkerRef.current.y = position.y;
          }
          if (selectionInfoRef.current) {
            selectionInfoRef.current.x = position.x + 25;
            selectionInfoRef.current.y = position.y - 30;
          }
        }

        // Animate mining lasers
        let lasers = laserGraphicsMap.get(ship.symbol);
        if (ship.cooldown && ship.cooldown.remainingSeconds > 0) {
          // Create lasers if mining started and they don't exist yet
          if (!lasers) {
            const waypoint = waypoints.get(ship.nav.waypointSymbol);
            if (waypoint) {
              lasers = [];
              for (let i = 0; i < 3; i++) {
                const laser = new PIXI.Graphics();
                laser.label = 'ship';
                lasers.push(laser);
                container.addChild(laser);
              }
              laserGraphicsMap.set(ship.symbol, lasers);
            }
          }

          // Animate lasers
          if (lasers) {
            const waypoint = waypoints.get(ship.nav.waypointSymbol);
            if (waypoint) {
              const time = now / 1000; // Convert to seconds for smoother animation
              lasers.forEach((laser, i) => {
                laser.clear();

                // Create pulsing effect with phase offset for each laser
                const phase = (time * 3 + i * 0.5) % 1; // Cycle every ~0.33 seconds
                const alpha = 0.5 + Math.sin(phase * Math.PI * 2) * 0.4; // Oscillate between 0.1 and 0.9

                // Add slight random offset to make lasers more dynamic
                const offset = (i - 1) * 2; // -2, 0, 2 pixel offset
                const angle = Math.atan2(waypoint.y - position.y, waypoint.x - position.x);
                const perpX = Math.cos(angle + Math.PI / 2) * offset;
                const perpY = Math.sin(angle + Math.PI / 2) * offset;

                // Draw laser from ship to waypoint
                laser.moveTo(position.x, position.y);
                laser.lineTo(waypoint.x + perpX, waypoint.y + perpY);
                laser.stroke({ color: 0xff0000, width: 0.3, alpha });
              });
            }
          }
        } else if (lasers) {
          // Clear lasers when mining stops
          lasers.forEach(laser => laser.clear());
        }

        // Update rotation for IN_TRANSIT ships
        if (ship.nav.status === 'IN_TRANSIT' && ship.nav.route?.destination) {
          const dest = ship.nav.route.destination;
          if (dest.x && dest.y) {
            const angle = Math.atan2(dest.y - position.y, dest.x - position.x);
            shipGraphic.rotation = angle + Math.PI / 2;
          }
        } else if (ship.nav.status === 'IN_ORBIT') {
          // Update rotation for IN_ORBIT ships to face orbital direction
          const waypointSymbol = ship.nav.waypointSymbol;
          const waypoint = waypoints.get(waypointSymbol);
          if (waypoint) {
            const dx = position.x - waypoint.x;
            const dy = position.y - waypoint.y;
            const orbitalAngle = Math.atan2(dy, dx);
            shipGraphic.rotation = orbitalAngle + Math.PI;
          }
        }

        // Add to trail periodically
        if (Math.random() < 0.1) { // 10% chance each frame to reduce trail density
          addTrailPosition(ship.symbol, {
            shipSymbol: ship.symbol,
            x: position.x,
            y: position.y,
            timestamp: Date.now(),
          });
        }
      });
    };

    app.ticker.add(ticker);

    return () => {
      if (appRef.current) {
        appRef.current.ticker.remove(ticker);
      }
    };
  }, [ships, waypoints, showLabels, addTrailPosition, agents, filterStatus, filterAgents, currentSystem]);

  // Draw selection marker
  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;

    // Remove previous selection marker
    container.children.filter(child => child.label === 'selection').forEach(child => {
      container.removeChild(child);
    });

    // If no object is selected, we're done
    if (!selectedObject) {
      selectionMarkerRef.current = null;
      selectionInfoRef.current = null;
      return;
    }

    // Get current position (for ships, use interpolated position)
    let currentX = selectedObject.x;
    let currentY = selectedObject.y;
    if (selectedObject.type === 'ship') {
      const ship = ships.find(s => s.symbol === selectedObject.symbol);
      if (ship) {
        const position = interpolateShipPosition(ship, waypoints);
        currentX = position.x;
        currentY = position.y;
      }
    }

    // Draw new selection marker
    const marker = new PIXI.Graphics();
    const size = selectedObject.type === 'waypoint' ? 15 : 12;

    // Animated selection ring
    marker.circle(0, 0, size);
    marker.stroke({ color: 0x00ff00, width: 2, alpha: 0.9 });

    // Corner brackets for selection indicator
    const bracketSize = size + 4;
    const bracketLength = 6;

    // Top-left
    marker.moveTo(-bracketSize, -bracketSize);
    marker.lineTo(-bracketSize + bracketLength, -bracketSize);
    marker.moveTo(-bracketSize, -bracketSize);
    marker.lineTo(-bracketSize, -bracketSize + bracketLength);

    // Top-right
    marker.moveTo(bracketSize, -bracketSize);
    marker.lineTo(bracketSize - bracketLength, -bracketSize);
    marker.moveTo(bracketSize, -bracketSize);
    marker.lineTo(bracketSize, -bracketSize + bracketLength);

    // Bottom-left
    marker.moveTo(-bracketSize, bracketSize);
    marker.lineTo(-bracketSize + bracketLength, bracketSize);
    marker.moveTo(-bracketSize, bracketSize);
    marker.lineTo(-bracketSize, bracketSize - bracketLength);

    // Bottom-right
    marker.moveTo(bracketSize, bracketSize);
    marker.lineTo(bracketSize - bracketLength, bracketSize);
    marker.moveTo(bracketSize, bracketSize);
    marker.lineTo(bracketSize, bracketSize - bracketLength);

    marker.stroke({ color: 0x00ff00, width: 2, alpha: 0.8 });
    marker.label = 'selection';
    marker.x = currentX;
    marker.y = currentY;

    container.addChild(marker);
    selectionMarkerRef.current = marker;

    // Add info box for selected object
    const infoContainer = new PIXI.Container();
    infoContainer.x = currentX + 25;
    infoContainer.y = currentY - 30;
    infoContainer.label = 'selection';

    let yOffset = 4;
    const labels: PIXI.Text[] = [];

    if (selectedObject.type === 'ship') {
      const ship = ships.find(s => s.symbol === selectedObject.symbol);
      if (ship) {
        // Ship name
        const nameLabel = new PIXI.Text(ship.symbol, {
          fontSize: 8,
          fill: 0xffffff,
          fontWeight: '600',
        });
        nameLabel.x = 4;
        nameLabel.y = yOffset;
        labels.push(nameLabel);
        yOffset += nameLabel.height + 1;

        // Status
        let status = ship.nav.status.replace('_', ' ');
        // Add mining indicator if ship has active cooldown
        if (ship.cooldown && ship.cooldown.remainingSeconds > 0) {
          status += ' ⛏️';
        }
        const statusLabel = new PIXI.Text(status, {
          fontSize: 7,
          fill: 0x88ccff,
        });
        statusLabel.x = 4;
        statusLabel.y = yOffset;
        labels.push(statusLabel);
        yOffset += statusLabel.height + 1;

        // Route if in transit with ETA
        if (ship.nav.status === 'IN_TRANSIT' && ship.nav.route) {
          const origin = ship.nav.route.origin.symbol.split('-').pop();
          const dest = ship.nav.route.destination.symbol.split('-').pop();

          // Calculate ETA in hh:mm:ss format
          const arrivalTime = new Date(ship.nav.route.arrival).getTime();
          const now = Date.now();
          const remainingMs = Math.max(0, arrivalTime - now);
          const totalSeconds = Math.floor(remainingMs / 1000);
          const hours = Math.floor(totalSeconds / 3600);
          const minutes = Math.floor((totalSeconds % 3600) / 60);
          const seconds = totalSeconds % 60;
          const etaText = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

          const routeLabel = new PIXI.Text(`${origin}→${dest} (${etaText})`, {
            fontSize: 7,
            fill: 0xaaaaaa,
          });
          routeLabel.x = 4;
          routeLabel.y = yOffset;
          labels.push(routeLabel);
          yOffset += routeLabel.height + 2;
        }

        // Flight mode
        const flightModeLabel = new PIXI.Text(ship.nav.flightMode, {
          fontSize: 6,
          fill: 0x888888,
        });
        flightModeLabel.x = 4;
        flightModeLabel.y = yOffset;
        labels.push(flightModeLabel);
        yOffset += flightModeLabel.height + 1;

        // Fuel
        const fuelLabel = new PIXI.Text(`⛽ ${ship.fuel.current}/${ship.fuel.capacity}`, {
          fontSize: 7,
          fill: 0x999999,
        });
        fuelLabel.x = 4;
        fuelLabel.y = yOffset;
        labels.push(fuelLabel);
        yOffset += fuelLabel.height + 1;

        // Cargo
        const cargoLabel = new PIXI.Text(`📦 ${ship.cargo.units}/${ship.cargo.capacity}`, {
          fontSize: 7,
          fill: 0x999999,
        });
        cargoLabel.x = 4;
        cargoLabel.y = yOffset;
        labels.push(cargoLabel);
        yOffset += cargoLabel.height + 4;
      }
    } else if (selectedObject.type === 'waypoint') {
      const waypoint = waypoints.get(selectedObject.symbol);
      if (waypoint) {
        // Waypoint name
        const nameLabel = new PIXI.Text(waypoint.symbol, {
          fontSize: 8,
          fill: 0xffffff,
          fontWeight: '600',
        });
        nameLabel.x = 4;
        nameLabel.y = yOffset;
        labels.push(nameLabel);
        yOffset += nameLabel.height + 1;

        // Type
        const typeLabel = new PIXI.Text(waypoint.type.replace(/_/g, ' '), {
          fontSize: 7,
          fill: 0x88ccff,
        });
        typeLabel.x = 4;
        typeLabel.y = yOffset;
        labels.push(typeLabel);
        yOffset += typeLabel.height + 1;

        // Marketplace trait
        const hasMarket = waypoint.traits.some(t => t.symbol === 'MARKETPLACE');
        if (hasMarket) {
          const marketLabel = new PIXI.Text('$ MARKETPLACE', {
            fontSize: 7,
            fill: 0xf39c12,
            fontWeight: '600',
          });
          marketLabel.x = 4;
          marketLabel.y = yOffset;
          labels.push(marketLabel);
          yOffset += marketLabel.height + 4;
        } else {
          yOffset += 4;
        }
      }
    }

    // Calculate dimensions
    const maxWidth = Math.max(...labels.map(l => l.width));
    const totalWidth = maxWidth + 8;
    const totalHeight = yOffset;

    // Background
    const infoBg = new PIXI.Graphics();
    infoBg.rect(0, 0, totalWidth, totalHeight);
    infoBg.fill({ color: 0x1a1a1a, alpha: 0.85 });
    infoBg.stroke({ color: 0x00ff00, width: 1, alpha: 0.6 });

    // Add all to container
    infoContainer.addChild(infoBg);
    labels.forEach(label => infoContainer.addChild(label));

    container.addChild(infoContainer);
    selectionInfoRef.current = infoContainer;
  }, [selectedObject, ships, waypoints]);

  // Get waypoint tooltip data
  const waypointTooltip = hoveredWaypoint ? (() => {
    const waypoint = waypoints.get(hoveredWaypoint);
    if (!waypoint) return null;

    const market = markets.get(hoveredWaypoint);
    const hasMarketplace = waypoint.traits.some((t) => t.symbol === 'MARKETPLACE');

    // Get market data if available
    let marketData = null;
    if (market && hasMarketplace && showMarkets) {
      const opportunities = getWaypointOpportunities(hoveredWaypoint, markets, 2);
      marketData = {
        importsCount: market.imports.length,
        exportsCount: market.exports.length,
        opportunities: opportunities.map(formatOpportunity),
      };
    }

    return {
      symbol: hoveredWaypoint,
      type: waypoint.type,
      x: waypoint.x,
      y: waypoint.y,
      traits: waypoint.traits,
      faction: waypoint.faction,
      hasMarketplace,
      marketData,
    };
  })() : null;

  return (
    <div className="relative w-full h-full">
      <div ref={canvasRef} className="w-full h-full" />

      {/* Controls overlay */}
      <div className="absolute top-4 left-4 bg-gray-800 bg-opacity-80 rounded p-3 text-sm">
        <div className="mb-2">
          <strong>System:</strong> {currentSystem || 'None selected'}
        </div>
        <div>
          <strong>Ships:</strong> {ships.length}
        </div>
        <div className="mb-3">
          <strong>Waypoints:</strong> {waypoints.size}
        </div>
        <div className="text-xs text-gray-400 border-t border-gray-600 pt-2">
          <div>🖱️ Drag to pan</div>
          <div>🔍 Scroll to zoom</div>
        </div>
      </div>

      {/* Waypoint tooltip */}
      {waypointTooltip && (
        <div
          className="fixed bg-gray-800 bg-opacity-95 rounded-lg p-3 text-xs min-w-[200px] border border-gray-600 pointer-events-none z-20 shadow-lg"
          style={{
            left: `${mousePosition.x + 10}px`,
            bottom: `${window.innerHeight - mousePosition.y + 10}px`,
          }}
        >
          <div className="font-bold mb-1 text-sm">{waypointTooltip.symbol}</div>
          <div className="text-gray-300 mb-2">{waypointTooltip.type.replace(/_/g, ' ')}</div>

          <div className="text-gray-400 text-xs mb-2">
            <div>X: {waypointTooltip.x}</div>
            <div>Y: {waypointTooltip.y}</div>
          </div>

          {waypointTooltip.faction && (
            <div className="text-blue-400 mb-2">
              Faction: {waypointTooltip.faction.symbol}
            </div>
          )}

          {waypointTooltip.traits.length > 0 && (
            <div className="mb-2">
              <div className="text-gray-400 mb-1">Traits:</div>
              <div className="flex flex-wrap gap-1">
                {waypointTooltip.traits.slice(0, 3).map((trait, i) => (
                  <span key={i} className="bg-gray-700 px-2 py-0.5 rounded text-xs">
                    {trait.symbol.replace(/_/g, ' ')}
                  </span>
                ))}
                {waypointTooltip.traits.length > 3 && (
                  <span className="text-gray-500">+{waypointTooltip.traits.length - 3} more</span>
                )}
              </div>
            </div>
          )}

          {waypointTooltip.marketData && (
            <div className="border-t border-gray-600 pt-2 mt-2">
              <div className="text-yellow-400 flex items-center gap-2 mb-1">
                <span>🏪</span> Market
              </div>
              <div className="text-xs">↓ {waypointTooltip.marketData.importsCount} Imports</div>
              <div className="text-xs mb-2">↑ {waypointTooltip.marketData.exportsCount} Exports</div>

              {waypointTooltip.marketData.opportunities.length > 0 && (
                <>
                  <div className="text-gray-400 mb-1">Opportunities:</div>
                  <ul className="text-green-400 text-xs">
                    {waypointTooltip.marketData.opportunities.map((opp, i) => (
                      <li key={i} className="mb-1">• {opp}</li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {!currentSystem && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-gray-800 bg-opacity-90 rounded-lg p-8 text-center">
            <h2 className="text-xl font-bold mb-2">No System Selected</h2>
            <p className="text-gray-400">Add an agent and select a system to begin</p>
          </div>
        </div>
      )}

      {/* Zoom Controls */}
      <ZoomControls
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onReset={handleResetView}
        onFitView={handleFitView}
      />

      {/* Legend */}
      <Legend />

      {/* Minimap */}
      <Minimap
        waypoints={waypoints}
        viewportBounds={viewportBounds}
        onNavigate={handleMinimapNavigate}
      />
    </div>
  );
});

SpaceMap.displayName = 'SpaceMap';

export default SpaceMap;
