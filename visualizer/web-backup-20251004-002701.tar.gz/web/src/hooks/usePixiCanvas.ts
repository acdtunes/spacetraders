import { useEffect, useRef, useState } from 'react';
import * as PIXI from 'pixi.js';
import { PIXI_CONSTANTS } from '../constants/pixi';

export interface PixiCanvasConfig {
  width: number;
  height: number;
  backgroundColor?: number;
  minScale?: number;
  maxScale?: number;
  zoomInFactor?: number;
  zoomOutFactor?: number;
}

export interface PixiCanvasResult {
  app: PIXI.Application | null;
  container: PIXI.Container | null;
  isReady: boolean;
}

/**
 * Custom hook for managing PixiJS canvas with pan and zoom
 * @param canvasRef - Ref to the div that will contain the canvas
 * @param config - Canvas configuration
 * @returns Object containing app, container, and ready state
 */
export function usePixiCanvas(
  canvasRef: React.RefObject<HTMLDivElement>,
  config: PixiCanvasConfig
): PixiCanvasResult {
  const appRef = useRef<PIXI.Application | null>(null);
  const containerRef = useRef<PIXI.Container | null>(null);
  const [isReady, setIsReady] = useState(false);

  const {
    width,
    height,
    backgroundColor = 0x000411,
    minScale = PIXI_CONSTANTS.MIN_ZOOM_SPACE,
    maxScale = PIXI_CONSTANTS.MAX_ZOOM_SPACE,
    zoomInFactor = PIXI_CONSTANTS.ZOOM_IN_FACTOR,
    zoomOutFactor = PIXI_CONSTANTS.ZOOM_OUT_FACTOR,
  } = config;

  useEffect(() => {
    if (!canvasRef.current) return;

    let mounted = true;

    (async () => {
      const app = new PIXI.Application();

      await app.init({
        width,
        height,
        backgroundColor,
        antialias: true,
        autoDensity: true,
        resolution: window.devicePixelRatio || 1,
      });

      if (!mounted) {
        app.destroy(true);
        return;
      }

      if (canvasRef.current) {
        canvasRef.current.appendChild(app.canvas);
      }

      const container = new PIXI.Container();
      app.stage.addChild(container);
      containerRef.current = container;
      appRef.current = app;

      // Initialize container at canvas center
      container.x = app.canvas.width / 2;
      container.y = app.canvas.height / 2;

      // Pan and zoom state
      let isDragging = false;
      let dragStart = { x: 0, y: 0 };

      // Mouse wheel zoom
      const handleWheel = (e: WheelEvent) => {
        e.preventDefault();
        const delta = e.deltaY > 0 ? zoomOutFactor : zoomInFactor;
        const currentScale = container.scale.x;
        const newScale = Math.max(minScale, Math.min(maxScale, currentScale * delta));
        container.scale.set(newScale, newScale);
      };

      // Mouse drag pan
      const handleMouseDown = (e: MouseEvent) => {
        isDragging = true;
        dragStart = { x: e.clientX - container.x, y: e.clientY - container.y };
      };

      const handleMouseMove = (e: MouseEvent) => {
        if (!isDragging) return;
        container.x = e.clientX - dragStart.x;
        container.y = e.clientY - dragStart.y;
      };

      const handleMouseUp = () => {
        isDragging = false;
      };

      // Handle window resize
      const handleResize = () => {
        if (appRef.current) {
          appRef.current.renderer.resize(width, height);
        }
      };

      // Add event listeners
      app.canvas.addEventListener('wheel', handleWheel);
      app.canvas.addEventListener('mousedown', handleMouseDown);
      app.canvas.addEventListener('mousemove', handleMouseMove);
      app.canvas.addEventListener('mouseup', handleMouseUp);
      app.canvas.addEventListener('mouseleave', handleMouseUp);
      window.addEventListener('resize', handleResize);

      setIsReady(true);

      // Cleanup function stored in closure
      return () => {
        app.canvas.removeEventListener('wheel', handleWheel);
        app.canvas.removeEventListener('mousedown', handleMouseDown);
        app.canvas.removeEventListener('mousemove', handleMouseMove);
        app.canvas.removeEventListener('mouseup', handleMouseUp);
        app.canvas.removeEventListener('mouseleave', handleMouseUp);
        window.removeEventListener('resize', handleResize);
      };
    })();

    return () => {
      mounted = false;
      setIsReady(false);
      if (appRef.current) {
        appRef.current.destroy(true);
        appRef.current = null;
        containerRef.current = null;
      }
    };
  }, [canvasRef, width, height, backgroundColor, minScale, maxScale, zoomInFactor, zoomOutFactor]);

  return {
    app: appRef.current,
    container: containerRef.current,
    isReady,
  };
}
