import type { Waypoint, Ship } from '../types/spacetraders';
import { PIXI_CONSTANTS } from '../constants/pixi';

/**
 * Get waypoint radius based on type
 * Varies by type and uses position-based hashing for diversity
 */
export function getWaypointRadius(waypoint: Waypoint): number {
  if (waypoint.type.includes('PLANET')) {
    // Vary planet size based on position hash for diversity
    const hash = (waypoint.x * 73856093) ^ (waypoint.y * 19349663);
    const sizeVariation = (Math.abs(hash) % 6) + 1; // 1 to 6
    return 5 + sizeVariation; // 6 to 11
  } else if (waypoint.type.includes('GAS_GIANT')) {
    // Gas giants also vary in size
    const hash = (waypoint.x * 73856093) ^ (waypoint.y * 19349663);
    const sizeVariation = (Math.abs(hash) % 5) + 1; // 1 to 5
    return 10 + sizeVariation; // 11 to 15
  } else if (waypoint.type === 'MOON') {
    // Moons vary in size
    const hash = (waypoint.x * 73856093) ^ (waypoint.y * 19349663);
    const sizeVariation = (Math.abs(hash) % 4) + 1; // 1 to 4
    return 3 + sizeVariation; // 4 to 7
  } else if (waypoint.type.includes('STATION')) {
    return 5;
  }
  return 3;
}

/**
 * Calculate ship position based on nav status
 * - IN_ORBIT: Calculate orbital position around waypoint
 * - DOCKED: Position at waypoint
 * - IN_TRANSIT: Interpolate between origin and destination
 */
export function interpolateShipPosition(ship: Ship, waypoints: Map<string, Waypoint>): { x: number; y: number } {
  // IN_ORBIT ships - calculate orbital position
  if (ship.nav.status === 'IN_ORBIT') {
    const waypointSymbol = ship.nav.waypointSymbol;
    const waypoint = waypoints.get(waypointSymbol);
    if (!waypoint) return { x: 0, y: 0 };

    // Orbit parameters - radius proportional to waypoint size
    const waypointRadius = getWaypointRadius(waypoint);
    // Smaller orbit distance for asteroids
    const orbitDistance = waypoint.type.includes('ASTEROID')
      ? PIXI_CONSTANTS.ORBIT_DISTANCE_ASTEROID
      : PIXI_CONSTANTS.ORBIT_DISTANCE_DEFAULT;
    const orbitRadius = waypointRadius + orbitDistance;
    const orbitPeriod = PIXI_CONSTANTS.ORBIT_PERIOD;
    const currentTime = Date.now();
    const angle = (currentTime % orbitPeriod) / orbitPeriod * Math.PI * 2;

    return {
      x: waypoint.x + Math.cos(angle) * orbitRadius,
      y: waypoint.y + Math.sin(angle) * orbitRadius,
    };
  }

  if (ship.nav.status !== 'IN_TRANSIT') {
    const waypointSymbol = ship.nav.waypointSymbol;
    const waypoint = waypoints.get(waypointSymbol);
    if (!waypoint) return { x: 0, y: 0 };
    return { x: waypoint.x, y: waypoint.y };
  }

  // IN_TRANSIT ships should have route data
  if (!ship.nav.route?.destination) {
    return { x: 0, y: 0 };
  }

  // Get origin from route
  const origin = ship.nav.route.origin;
  if (!origin || !origin.x || !origin.y) {
    return { x: 0, y: 0 };
  }

  const dest = ship.nav.route.destination;
  if (!dest.x || !dest.y) {
    return { x: 0, y: 0 };
  }

  const departureTime = new Date(ship.nav.route.departureTime).getTime();
  const arrivalTime = new Date(ship.nav.route.arrival).getTime();
  const now = Date.now();

  const progress = (now - departureTime) / (arrivalTime - departureTime);
  const clampedProgress = Math.max(0, Math.min(1, progress));

  return {
    x: origin.x + (dest.x - origin.x) * clampedProgress,
    y: origin.y + (dest.y - origin.y) * clampedProgress,
  };
}
