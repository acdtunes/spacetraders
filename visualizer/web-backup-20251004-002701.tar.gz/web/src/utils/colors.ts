/**
 * Lighten a color by adding to each RGB component
 * @param color - Hex color value (e.g., 0xFF0000)
 * @param amount - Amount to add to each component (0-255)
 * @returns Lightened color
 */
export function lightenColor(color: number, amount: number = 50): number {
  const r = Math.min(255, ((color >> 16) & 0xFF) + amount);
  const g = Math.min(255, ((color >> 8) & 0xFF) + amount);
  const b = Math.min(255, (color & 0xFF) + amount);
  return (r << 16) | (g << 8) | b;
}

/**
 * Darken a color by subtracting from each RGB component
 * @param color - Hex color value (e.g., 0xFF0000)
 * @param amount - Amount to subtract from each component (0-255)
 * @returns Darkened color
 */
export function darkenColor(color: number, amount: number = 50): number {
  const r = Math.max(0, ((color >> 16) & 0xFF) - amount);
  const g = Math.max(0, ((color >> 8) & 0xFF) - amount);
  const b = Math.max(0, (color & 0xFF) - amount);
  return (r << 16) | (g << 8) | b;
}
