import * as PIXI from 'pixi.js';
import { lightenColor, darkenColor } from '../../utils/colors';
import { PIXI_CONSTANTS, ENGINE_GLOW_COLOR, WINDOW_LIGHT_COLOR } from '../../constants/pixi';

/**
 * Draw ship shape based on role
 * Each role has a unique visual design inspired by sci-fi spacecraft
 */
export function drawShipShape(graphics: PIXI.Graphics, role: string, color: number): void {
  const alpha = 0.95;
  const scale = PIXI_CONSTANTS.SHIP_SCALE;
  const strokeWidth = PIXI_CONSTANTS.STROKE_WIDTH;

  switch (role.toUpperCase()) {
    case 'COMMAND':
      drawCommandShip(graphics, color, alpha, scale, strokeWidth);
      break;
    case 'HAULER':
    case 'FREIGHTER':
      drawHaulerShip(graphics, color, alpha, scale, strokeWidth);
      break;
    case 'EXCAVATOR':
    case 'REFINERY':
      drawMiningShip(graphics, color, alpha, scale, strokeWidth);
      break;
    case 'EXPLORER':
    case 'SURVEYOR':
      drawExplorerShip(graphics, color, alpha, scale, strokeWidth);
      break;
    case 'PATROL':
    case 'INTERCEPTOR':
      drawFighterShip(graphics, color, alpha, scale, strokeWidth);
      break;
    case 'SATELLITE':
    case 'PROBE':
      drawProbeShip(graphics, color, alpha, scale, strokeWidth);
      break;
    case 'REPAIR':
      drawRepairShip(graphics, color, alpha, scale, strokeWidth);
      break;
    default:
      drawGenericShip(graphics, color, alpha, scale, strokeWidth);
  }

  // Add outline for all shapes
  graphics.stroke({ color: 0xffffff, width: strokeWidth, alpha: 0.7 });
}

function drawCommandShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, strokeWidth: number): void {
  // Command cruiser - Star Destroyer inspired
  // Main hull
  graphics.moveTo(0, -8 * scale);
  graphics.lineTo(-2 * scale, -6 * scale);
  graphics.lineTo(-4 * scale, 2 * scale);
  graphics.lineTo(-3 * scale, 6 * scale);
  graphics.lineTo(3 * scale, 6 * scale);
  graphics.lineTo(4 * scale, 2 * scale);
  graphics.lineTo(2 * scale, -6 * scale);
  graphics.lineTo(0, -8 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });

  // Bridge tower
  graphics.rect(-1.5 * scale, -7 * scale, 3 * scale, 4 * scale);
  graphics.fill({ color: lightenColor(color, 30), alpha });

  // Superstructure detail
  graphics.rect(-0.8 * scale, -8 * scale, 1.6 * scale, 2 * scale);
  graphics.fill({ color: lightenColor(color, 50), alpha });

  // Hull panels
  graphics.moveTo(-3 * scale, 0);
  graphics.lineTo(3 * scale, 0);
  graphics.stroke({ color: darkenColor(color, 60), width: strokeWidth, alpha: 0.7 });
  graphics.moveTo(-3.5 * scale, 3 * scale);
  graphics.lineTo(3.5 * scale, 3 * scale);
  graphics.stroke({ color: darkenColor(color, 60), width: strokeWidth, alpha: 0.7 });

  // Engine arrays
  graphics.rect(-3.5 * scale, 5 * scale, 2 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });
  graphics.rect(1.5 * scale, 5 * scale, 2 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });

  // Engine glow
  graphics.circle(-2.5 * scale, 6.5 * scale, 1.2 * scale);
  graphics.fill({ color: ENGINE_GLOW_COLOR, alpha: 0.9 });
  graphics.circle(2.5 * scale, 6.5 * scale, 1.2 * scale);
  graphics.fill({ color: ENGINE_GLOW_COLOR, alpha: 0.9 });

  // Windows/lights
  graphics.rect(-0.5 * scale, -6 * scale, 1 * scale, 0.5 * scale);
  graphics.fill({ color: WINDOW_LIGHT_COLOR, alpha: 0.8 });

  // Outline
  graphics.moveTo(0, -8 * scale);
  graphics.lineTo(-2 * scale, -6 * scale);
  graphics.lineTo(-4 * scale, 2 * scale);
  graphics.lineTo(-3 * scale, 6 * scale);
  graphics.lineTo(3 * scale, 6 * scale);
  graphics.lineTo(4 * scale, 2 * scale);
  graphics.lineTo(2 * scale, -6 * scale);
  graphics.lineTo(0, -8 * scale);
  graphics.stroke({ color: lightenColor(color, 80), width: strokeWidth, alpha: 0.8 });
}

function drawHaulerShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, strokeWidth: number): void {
  // Industrial freighter - Serenity/cargo hauler style
  // Front cockpit section
  graphics.moveTo(0, -6 * scale);
  graphics.lineTo(-2 * scale, -4 * scale);
  graphics.lineTo(-2 * scale, -2 * scale);
  graphics.lineTo(2 * scale, -2 * scale);
  graphics.lineTo(2 * scale, -4 * scale);
  graphics.lineTo(0, -6 * scale);
  graphics.fill({ color: lightenColor(color, 40), alpha });

  // Large cargo bay - main body
  graphics.rect(-4 * scale, -2 * scale, 8 * scale, 7 * scale);
  graphics.fill({ color, alpha });

  // Cargo containers on top
  graphics.rect(-3.5 * scale, -1 * scale, 3 * scale, 2.5 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });
  graphics.rect(0.5 * scale, -1 * scale, 3 * scale, 2.5 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });

  // Container details
  graphics.moveTo(-2 * scale, -1 * scale);
  graphics.lineTo(-2 * scale, 1.5 * scale);
  graphics.stroke({ color: darkenColor(color, 70), width: strokeWidth, alpha: 0.8 });
  graphics.moveTo(2 * scale, -1 * scale);
  graphics.lineTo(2 * scale, 1.5 * scale);
  graphics.stroke({ color: darkenColor(color, 70), width: strokeWidth, alpha: 0.8 });

  // Side cargo hatches
  graphics.rect(-4.5 * scale, 1 * scale, 0.8 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(3.7 * scale, 1 * scale, 0.8 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });

  // Engine nacelles
  graphics.rect(-4 * scale, 4.5 * scale, 2.5 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });
  graphics.rect(1.5 * scale, 4.5 * scale, 2.5 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });

  // Engine exhaust
  graphics.circle(-2.8 * scale, 6 * scale, 1.1 * scale);
  graphics.fill({ color: 0xff8800, alpha: 0.95 });
  graphics.circle(2.8 * scale, 6 * scale, 1.1 * scale);
  graphics.fill({ color: 0xff8800, alpha: 0.95 });

  // Cockpit windows
  graphics.rect(-1.2 * scale, -5 * scale, 2.4 * scale, 1 * scale);
  graphics.fill({ color: 0x88ddff, alpha: 0.9 });

  // Communications array
  graphics.moveTo(0, -2 * scale);
  graphics.lineTo(0, -3.5 * scale);
  graphics.stroke({ color: 0xcccccc, width: strokeWidth, alpha: 0.8 });
  graphics.circle(0, -3.5 * scale, 0.5 * scale);
  graphics.fill({ color: 0xff4444, alpha: 0.9 });
}

function drawMiningShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, _strokeWidth: number): void {
  // Mining vessel - heavy industrial with excavation arms
  // Central hull
  graphics.rect(-3 * scale, -3 * scale, 6 * scale, 6 * scale);
  graphics.fill({ color, alpha });

  // Front drill housing
  graphics.moveTo(0, -5 * scale);
  graphics.lineTo(-2 * scale, -3 * scale);
  graphics.lineTo(2 * scale, -3 * scale);
  graphics.lineTo(0, -5 * scale);
  graphics.fill({ color: lightenColor(color, 30), alpha });

  // Mining arm joints
  graphics.circle(-3 * scale, 0, 1.2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });
  graphics.circle(3 * scale, 0, 1.2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });

  // Extended drill arms
  graphics.rect(-6.5 * scale, -1 * scale, 3.5 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });
  graphics.rect(3 * scale, -1 * scale, 3.5 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });

  // Drill heads
  graphics.circle(-6.5 * scale, 0, 1.3 * scale);
  graphics.fill({ color: 0xff9900, alpha: 0.95 });
  graphics.circle(6.5 * scale, 0, 1.3 * scale);
  graphics.fill({ color: 0xff9900, alpha: 0.95 });

  // Drill bits
  graphics.circle(-6.5 * scale, 0, 0.6 * scale);
  graphics.fill({ color: 0xffdd00, alpha: 0.95 });
  graphics.circle(6.5 * scale, 0, 0.6 * scale);
  graphics.fill({ color: 0xffdd00, alpha: 0.95 });

  // Processing unit/refinery
  graphics.circle(0, 0, 2 * scale);
  graphics.fill({ color: lightenColor(color, 40), alpha });
  graphics.circle(0, 0, 1.2 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });

  // Cargo holds
  graphics.rect(-2.5 * scale, 2 * scale, 2 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(0.5 * scale, 2 * scale, 2 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });

  // Thrusters
  graphics.rect(-2 * scale, 4 * scale, 1.5 * scale, 1.5 * scale);
  graphics.fill({ color: 0xff6600, alpha: 0.9 });
  graphics.rect(0.5 * scale, 4 * scale, 1.5 * scale, 1.5 * scale);
  graphics.fill({ color: 0xff6600, alpha: 0.9 });

  // Industrial lights
  graphics.circle(-1 * scale, -2 * scale, 0.4 * scale);
  graphics.fill({ color: WINDOW_LIGHT_COLOR, alpha: 0.9 });
  graphics.circle(1 * scale, -2 * scale, 0.4 * scale);
  graphics.fill({ color: WINDOW_LIGHT_COLOR, alpha: 0.9 });
}

function drawExplorerShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, strokeWidth: number): void {
  // Science vessel - Enterprise inspired
  // Saucer section
  graphics.circle(0, -2 * scale, 3 * scale);
  graphics.fill({ color, alpha });

  // Bridge dome
  graphics.circle(0, -3 * scale, 1.2 * scale);
  graphics.fill({ color: lightenColor(color, 40), alpha });
  graphics.circle(0, -3 * scale, 0.6 * scale);
  graphics.fill({ color: 0x88ddff, alpha: 0.95 });

  // Engineering hull
  graphics.moveTo(-1 * scale, 0);
  graphics.lineTo(-1.5 * scale, 6 * scale);
  graphics.lineTo(1.5 * scale, 6 * scale);
  graphics.lineTo(1 * scale, 0);
  graphics.lineTo(-1 * scale, 0);
  graphics.fill({ color: darkenColor(color, 20), alpha });

  // Nacelle struts
  graphics.rect(-4 * scale, 1 * scale, 1 * scale, 3 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(3 * scale, 1 * scale, 1 * scale, 3 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });

  // Warp nacelles
  graphics.rect(-5 * scale, 2 * scale, 2 * scale, 5 * scale);
  graphics.fill({ color: lightenColor(color, 20), alpha });
  graphics.rect(3 * scale, 2 * scale, 2 * scale, 5 * scale);
  graphics.fill({ color: lightenColor(color, 20), alpha });

  // Nacelle glow (warp coils)
  graphics.rect(-4.8 * scale, 2.5 * scale, 1.6 * scale, 1 * scale);
  graphics.fill({ color: 0x00aaff, alpha: 0.9 });
  graphics.rect(-4.8 * scale, 4.5 * scale, 1.6 * scale, 1 * scale);
  graphics.fill({ color: 0x00aaff, alpha: 0.9 });
  graphics.rect(3.2 * scale, 2.5 * scale, 1.6 * scale, 1 * scale);
  graphics.fill({ color: 0x00aaff, alpha: 0.9 });
  graphics.rect(3.2 * scale, 4.5 * scale, 1.6 * scale, 1 * scale);
  graphics.fill({ color: 0x00aaff, alpha: 0.9 });

  // Deflector dish
  graphics.circle(0, 3 * scale, 1 * scale);
  graphics.fill({ color: 0x00ffaa, alpha: 0.9 });
  graphics.circle(0, 3 * scale, 1.5 * scale);
  graphics.stroke({ color: 0x00ffaa, width: strokeWidth, alpha: 0.7 });

  // Sensor array on saucer
  graphics.circle(-2 * scale, -2 * scale, 0.4 * scale);
  graphics.fill({ color: 0x00ff88, alpha: 0.9 });
  graphics.circle(2 * scale, -2 * scale, 0.4 * scale);
  graphics.fill({ color: 0x00ff88, alpha: 0.9 });

  // Impulse engines
  graphics.rect(-1.2 * scale, -0.5 * scale, 2.4 * scale, 1 * scale);
  graphics.fill({ color: 0xff6600, alpha: 0.9 });
}

function drawFighterShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, strokeWidth: number): void {
  // Starfighter - X-Wing/Viper inspired
  // Fuselage
  graphics.moveTo(0, -7 * scale);
  graphics.lineTo(-1.5 * scale, -5 * scale);
  graphics.lineTo(-1.2 * scale, 4 * scale);
  graphics.lineTo(1.2 * scale, 4 * scale);
  graphics.lineTo(1.5 * scale, -5 * scale);
  graphics.lineTo(0, -7 * scale);
  graphics.fill({ color, alpha });

  // Cockpit canopy
  graphics.circle(0, -4 * scale, 1.4 * scale);
  graphics.fill({ color: 0x44aaff, alpha: 0.9 });
  graphics.circle(0, -4 * scale, 1.8 * scale);
  graphics.stroke({ color: lightenColor(color, 60), width: strokeWidth, alpha: 0.8 });

  // S-foils/wings (top)
  graphics.moveTo(-1.5 * scale, -2 * scale);
  graphics.lineTo(-5 * scale, -3 * scale);
  graphics.lineTo(-5.5 * scale, 1 * scale);
  graphics.lineTo(-2 * scale, 2 * scale);
  graphics.lineTo(-1.5 * scale, -2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });

  graphics.moveTo(1.5 * scale, -2 * scale);
  graphics.lineTo(5 * scale, -3 * scale);
  graphics.lineTo(5.5 * scale, 1 * scale);
  graphics.lineTo(2 * scale, 2 * scale);
  graphics.lineTo(1.5 * scale, -2 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });

  // Weapon mounts
  graphics.circle(-5 * scale, -1 * scale, 0.7 * scale);
  graphics.fill({ color: 0xff3300, alpha: 0.95 });
  graphics.circle(5 * scale, -1 * scale, 0.7 * scale);
  graphics.fill({ color: 0xff3300, alpha: 0.95 });

  // Engine pods
  graphics.rect(-2.2 * scale, 3 * scale, 1.5 * scale, 2.5 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(0.7 * scale, 3 * scale, 1.5 * scale, 2.5 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });

  // Engine exhaust glow
  graphics.circle(-1.5 * scale, 5.2 * scale, 1 * scale);
  graphics.fill({ color: 0xff4400, alpha: 0.95 });
  graphics.circle(1.5 * scale, 5.2 * scale, 1 * scale);
  graphics.fill({ color: 0xff4400, alpha: 0.95 });

  // Reactor vent
  graphics.rect(-0.5 * scale, 1 * scale, 1 * scale, 1.5 * scale);
  graphics.fill({ color: 0x00ffff, alpha: 0.7 });

  // Panel lines
  graphics.moveTo(0, -7 * scale);
  graphics.lineTo(0, 4 * scale);
  graphics.stroke({ color: darkenColor(color, 50), width: strokeWidth, alpha: 0.7 });
}

function drawProbeShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, strokeWidth: number): void {
  // Space probe with deployable arrays
  // Central body
  graphics.circle(0, 0, 2.2 * scale);
  graphics.fill({ color, alpha });

  // Instrument core
  graphics.circle(0, 0, 1.3 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });

  // Central sensor
  graphics.circle(0, 0, 0.7 * scale);
  graphics.fill({ color: lightenColor(color, 40), alpha });

  // Solar panel arms (4-way)
  graphics.rect(-6 * scale, -0.7 * scale, 3.5 * scale, 1.4 * scale);
  graphics.fill({ color: 0x0055cc, alpha: 0.85 });
  graphics.rect(2.5 * scale, -0.7 * scale, 3.5 * scale, 1.4 * scale);
  graphics.fill({ color: 0x0055cc, alpha: 0.85 });

  // Solar panel grid lines
  for (let i = -5.5; i < -2; i += 0.8) {
    graphics.moveTo(i * scale, -0.5 * scale);
    graphics.lineTo(i * scale, 0.5 * scale);
    graphics.stroke({ color: 0x003388, width: strokeWidth * 0.75, alpha: 0.6 });
  }
  for (let i = 3; i < 6; i += 0.8) {
    graphics.moveTo(i * scale, -0.5 * scale);
    graphics.lineTo(i * scale, 0.5 * scale);
    graphics.stroke({ color: 0x003388, width: strokeWidth * 0.75, alpha: 0.6 });
  }

  // Communications dish
  graphics.moveTo(0, -2.2 * scale);
  graphics.lineTo(0, -4 * scale);
  graphics.stroke({ color: 0xcccccc, width: strokeWidth, alpha: 0.8 });
  graphics.circle(0, -4.5 * scale, 1.2 * scale);
  graphics.fill({ color: lightenColor(color, 30), alpha: 0.8 });
  graphics.circle(0, -4.5 * scale, 0.5 * scale);
  graphics.fill({ color: 0xff2222, alpha: 0.95 });

  // Sensor booms
  graphics.moveTo(0, 2.2 * scale);
  graphics.lineTo(0, 4 * scale);
  graphics.stroke({ color: 0xcccccc, width: strokeWidth, alpha: 0.8 });
  graphics.circle(0, 4.2 * scale, 0.6 * scale);
  graphics.fill({ color: 0x00ff88, alpha: 0.9 });

  // Status lights
  graphics.circle(-1.5 * scale, 0, 0.3 * scale);
  graphics.fill({ color: 0x00ff00, alpha: 0.9 });
  graphics.circle(1.5 * scale, 0, 0.3 * scale);
  graphics.fill({ color: 0x00ff00, alpha: 0.9 });

  // Outer sensor ring
  graphics.circle(0, 0, 3.2 * scale);
  graphics.stroke({ color: lightenColor(color, 50), width: strokeWidth, alpha: 0.6 });
}

function drawRepairShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, _strokeWidth: number): void {
  // Utility ship with manipulator arms
  // Central workshop module
  graphics.circle(0, 0, 2.5 * scale);
  graphics.fill({ color, alpha });

  // Workshop core
  graphics.circle(0, 0, 1.8 * scale);
  graphics.fill({ color: darkenColor(color, 20), alpha });

  // Command pod
  graphics.circle(0, -1 * scale, 1 * scale);
  graphics.fill({ color: lightenColor(color, 40), alpha });
  graphics.circle(0, -1 * scale, 0.5 * scale);
  graphics.fill({ color: 0x88ddff, alpha: 0.9 });

  // Manipulator arms (4-way extending)
  // Top arm
  graphics.rect(-0.5 * scale, -2.5 * scale, 1 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(-0.5 * scale, -5.5 * scale, 1 * scale, 3 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });
  // Gripper
  graphics.rect(-1 * scale, -6 * scale, 2 * scale, 1.5 * scale);
  graphics.fill({ color: lightenColor(color, 20), alpha });
  graphics.circle(0, -5.5 * scale, 0.8 * scale);
  graphics.fill({ color: 0xffbb00, alpha: 0.9 });

  // Bottom arm
  graphics.rect(-0.5 * scale, 0.5 * scale, 1 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(-0.5 * scale, 2.5 * scale, 1 * scale, 3 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });
  graphics.rect(-1 * scale, 4.5 * scale, 2 * scale, 1.5 * scale);
  graphics.fill({ color: lightenColor(color, 20), alpha });
  graphics.circle(0, 5.5 * scale, 0.8 * scale);
  graphics.fill({ color: 0xffbb00, alpha: 0.9 });

  // Left arm
  graphics.rect(-2.5 * scale, -0.5 * scale, 2 * scale, 1 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(-5.5 * scale, -0.5 * scale, 3 * scale, 1 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });
  graphics.rect(-6 * scale, -1 * scale, 1.5 * scale, 2 * scale);
  graphics.fill({ color: lightenColor(color, 20), alpha });
  graphics.circle(-5.5 * scale, 0, 0.8 * scale);
  graphics.fill({ color: 0xffbb00, alpha: 0.9 });

  // Right arm
  graphics.rect(0.5 * scale, -0.5 * scale, 2 * scale, 1 * scale);
  graphics.fill({ color: darkenColor(color, 30), alpha });
  graphics.rect(2.5 * scale, -0.5 * scale, 3 * scale, 1 * scale);
  graphics.fill({ color: darkenColor(color, 40), alpha });
  graphics.rect(4.5 * scale, -1 * scale, 1.5 * scale, 2 * scale);
  graphics.fill({ color: lightenColor(color, 20), alpha });
  graphics.circle(5.5 * scale, 0, 0.8 * scale);
  graphics.fill({ color: 0xffbb00, alpha: 0.9 });

  // Welding torch indicators
  graphics.circle(0, -5.5 * scale, 0.4 * scale);
  graphics.fill({ color: 0xff4400, alpha: 0.95 });
  graphics.circle(0, 5.5 * scale, 0.4 * scale);
  graphics.fill({ color: 0xff4400, alpha: 0.95 });
  graphics.circle(-5.5 * scale, 0, 0.4 * scale);
  graphics.fill({ color: 0xff4400, alpha: 0.95 });
  graphics.circle(5.5 * scale, 0, 0.4 * scale);
  graphics.fill({ color: 0xff4400, alpha: 0.95 });

  // Status lights on core
  graphics.circle(-1.2 * scale, 0.8 * scale, 0.3 * scale);
  graphics.fill({ color: 0x00ff00, alpha: 0.9 });
  graphics.circle(1.2 * scale, 0.8 * scale, 0.3 * scale);
  graphics.fill({ color: 0x00ff00, alpha: 0.9 });
}

function drawGenericShip(graphics: PIXI.Graphics, color: number, alpha: number, scale: number, strokeWidth: number): void {
  // Generic spacecraft - shuttle style
  // Nose cone
  graphics.moveTo(0, -6 * scale);
  graphics.lineTo(-1.5 * scale, -3 * scale);
  graphics.lineTo(-2 * scale, -1 * scale);
  graphics.lineTo(2 * scale, -1 * scale);
  graphics.lineTo(1.5 * scale, -3 * scale);
  graphics.lineTo(0, -6 * scale);
  graphics.fill({ color: lightenColor(color, 30), alpha });

  // Main fuselage
  graphics.rect(-2 * scale, -1 * scale, 4 * scale, 6 * scale);
  graphics.fill({ color, alpha });

  // Cockpit windows
  graphics.rect(-1.3 * scale, -4 * scale, 2.6 * scale, 1.5 * scale);
  graphics.fill({ color: 0x66aaff, alpha: 0.9 });

  // Wings
  graphics.moveTo(-2 * scale, 1 * scale);
  graphics.lineTo(-4 * scale, 2 * scale);
  graphics.lineTo(-4 * scale, 4 * scale);
  graphics.lineTo(-2 * scale, 3 * scale);
  graphics.lineTo(-2 * scale, 1 * scale);
  graphics.fill({ color: darkenColor(color, 25), alpha });

  graphics.moveTo(2 * scale, 1 * scale);
  graphics.lineTo(4 * scale, 2 * scale);
  graphics.lineTo(4 * scale, 4 * scale);
  graphics.lineTo(2 * scale, 3 * scale);
  graphics.lineTo(2 * scale, 1 * scale);
  graphics.fill({ color: darkenColor(color, 25), alpha });

  // Engine nacelles
  graphics.rect(-2.5 * scale, 4 * scale, 1.5 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 35), alpha });
  graphics.rect(1 * scale, 4 * scale, 1.5 * scale, 2 * scale);
  graphics.fill({ color: darkenColor(color, 35), alpha });

  // Engine glow
  graphics.circle(-1.8 * scale, 5.8 * scale, 0.9 * scale);
  graphics.fill({ color: 0x00bbff, alpha: 0.95 });
  graphics.circle(1.8 * scale, 5.8 * scale, 0.9 * scale);
  graphics.fill({ color: 0x00bbff, alpha: 0.95 });

  // Navigation lights
  graphics.circle(-2.2 * scale, 0, 0.3 * scale);
  graphics.fill({ color: 0xff0000, alpha: 0.9 });
  graphics.circle(2.2 * scale, 0, 0.3 * scale);
  graphics.fill({ color: 0x00ff00, alpha: 0.9 });

  // Center line detail
  graphics.moveTo(0, -6 * scale);
  graphics.lineTo(0, 5 * scale);
  graphics.stroke({ color: darkenColor(color, 60), width: strokeWidth, alpha: 0.6 });
}
