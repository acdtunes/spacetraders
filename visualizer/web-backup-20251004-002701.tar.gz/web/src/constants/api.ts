export const API_CONSTANTS = {
  BASE_URL: '/api',
  POLL_INTERVAL: 10000, // milliseconds
  REQUEST_DELAY: 1000, // milliseconds between requests
  PAGINATION_LIMIT: 20,
} as const;
