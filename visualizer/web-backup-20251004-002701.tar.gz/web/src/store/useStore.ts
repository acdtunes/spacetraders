import { create } from 'zustand';
import type { Agent, Ship, Waypoint, ShipPosition, Market, System } from '../types/spacetraders';

interface AppState {
  // Agents
  agents: Agent[];
  setAgents: (agents: Agent[]) => void;
  addAgent: (agent: Agent) => void;
  updateAgent: (id: string, updates: Partial<Agent>) => void;
  removeAgent: (id: string) => void;

  // Ships
  ships: Ship[];
  setShips: (ships: Ship[]) => void;

  // Waypoints
  waypoints: Map<string, Waypoint>;
  setWaypoints: (waypoints: Waypoint[]) => void;

  // Current system
  currentSystem: string | null;
  setCurrentSystem: (systemSymbol: string | null) => void;

  // Ship trails
  trails: Map<string, ShipPosition[]>;
  addTrailPosition: (shipSymbol: string, position: ShipPosition) => void;

  // Markets
  markets: Map<string, Market>;
  setMarkets: (markets: Map<string, Market>) => void;
  updateMarket: (waypointSymbol: string, market: Market) => void;
  showMarkets: boolean;
  toggleMarkets: () => void;

  // Galaxy
  systems: System[];
  setSystems: (systems: System[]) => void;
  viewMode: 'system' | 'galaxy';
  setViewMode: (mode: 'system' | 'galaxy') => void;

  // UI state
  showLabels: boolean;
  toggleLabels: () => void;

  filterStatus: Set<string>;
  toggleStatusFilter: (status: string) => void;

  filterAgents: Set<string>;
  toggleAgentFilter: (agentId: string) => void;

  filterWaypointTypes: Set<string>;
  toggleWaypointTypeFilter: (type: string) => void;
  selectAllWaypointTypes: (types: string[]) => void;
  clearAllWaypointTypes: () => void;

  // Connection status
  isPolling: boolean;
  setPolling: (polling: boolean) => void;
  lastUpdate: number | null;
  setLastUpdate: (timestamp: number) => void;

  // Selection
  selectedShip: Ship | null;
  setSelectedShip: (ship: Ship | null) => void;
  selectedWaypoint: Waypoint | null;
  setSelectedWaypoint: (waypoint: Waypoint | null) => void;
}

export const useStore = create<AppState>((set) => ({
  // Agents
  agents: [],
  setAgents: (agents) => set({ agents }),
  addAgent: (agent) => set((state) => ({ agents: [...state.agents, agent] })),
  updateAgent: (id, updates) =>
    set((state) => ({
      agents: state.agents.map((a) => (a.id === id ? { ...a, ...updates } : a)),
    })),
  removeAgent: (id) => set((state) => ({ agents: state.agents.filter((a) => a.id !== id) })),

  // Ships
  ships: [],
  setShips: (ships) => set({ ships }),

  // Waypoints
  waypoints: new Map(),
  setWaypoints: (waypoints) =>
    set({
      waypoints: new Map(waypoints.map((w) => [w.symbol, w])),
    }),

  // Current system
  currentSystem: null,
  setCurrentSystem: (systemSymbol) => set({ currentSystem: systemSymbol }),

  // Ship trails
  trails: new Map(),
  addTrailPosition: (shipSymbol, position) =>
    set((state) => {
      const newTrails = new Map(state.trails);
      const trail = newTrails.get(shipSymbol) || [];
      const updated = [...trail, position].slice(-5); // Keep last 5
      newTrails.set(shipSymbol, updated);
      return { trails: newTrails };
    }),

  // Markets
  markets: new Map(),
  setMarkets: (markets) => set({ markets }),
  updateMarket: (waypointSymbol, market) =>
    set((state) => {
      const newMarkets = new Map(state.markets);
      newMarkets.set(waypointSymbol, market);
      return { markets: newMarkets };
    }),
  showMarkets: true,
  toggleMarkets: () => set((state) => ({ showMarkets: !state.showMarkets })),

  // Galaxy
  systems: [],
  setSystems: (systems) => set({ systems }),
  viewMode: 'system',
  setViewMode: (mode) => set({ viewMode: mode }),

  // UI state
  showLabels: true,
  toggleLabels: () => set((state) => ({ showLabels: !state.showLabels })),

  filterStatus: new Set(['IN_TRANSIT', 'DOCKED', 'IN_ORBIT']),
  toggleStatusFilter: (status) =>
    set((state) => {
      const newFilter = new Set(state.filterStatus);
      if (newFilter.has(status)) {
        newFilter.delete(status);
      } else {
        newFilter.add(status);
      }
      return { filterStatus: newFilter };
    }),

  filterAgents: new Set(),
  toggleAgentFilter: (agentId) =>
    set((state) => {
      const newFilter = new Set(state.filterAgents);
      if (newFilter.has(agentId)) {
        newFilter.delete(agentId);
      } else {
        newFilter.add(agentId);
      }
      return { filterAgents: newFilter };
    }),

  filterWaypointTypes: new Set(['PLANET', 'GAS_GIANT', 'MOON', 'ORBITAL_STATION', 'JUMP_GATE', 'ASTEROID_FIELD', 'ASTEROID', 'ENGINEERED_ASTEROID', 'ASTEROID_BASE', 'NEBULA', 'DEBRIS_FIELD', 'GRAVITY_WELL', 'ARTIFICIAL_GRAVITY_WELL', 'FUEL_STATION']),
  toggleWaypointTypeFilter: (type) =>
    set((state) => {
      const newFilter = new Set(state.filterWaypointTypes);
      if (newFilter.has(type)) {
        newFilter.delete(type);
      } else {
        newFilter.add(type);
      }
      return { filterWaypointTypes: newFilter };
    }),
  selectAllWaypointTypes: (types) => set({ filterWaypointTypes: new Set(types) }),
  clearAllWaypointTypes: () => set({ filterWaypointTypes: new Set() }),

  // Connection status
  isPolling: false,
  setPolling: (polling) => set({ isPolling: polling }),
  lastUpdate: null,
  setLastUpdate: (timestamp) => set({ lastUpdate: timestamp }),

  // Selection
  selectedShip: null,
  setSelectedShip: (ship) => set({ selectedShip: ship }),
  selectedWaypoint: null,
  setSelectedWaypoint: (waypoint) => set({ selectedWaypoint: waypoint }),
}));
